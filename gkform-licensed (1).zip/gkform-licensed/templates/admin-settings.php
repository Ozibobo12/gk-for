<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap gkform-wrap">

  <div class="gkf-page-header">
    <h1><span class="gkf-logo">GK</span> GK Form Settings</h1>
  </div>

  <form method="post" action="">
    <?php wp_nonce_field( 'gkform_settings' ); ?>
    <input type="hidden" name="gkform_save_settings" value="1"/>

    <div class="gkf-settings-grid">

      <!-- General -->
      <div class="gkf-card">
        <div class="gkf-card-header"><h3>📧 General</h3></div>
        <div class="gkf-card-body">
          <div class="gkf-field-group">
            <label for="admin_email"><?php esc_html_e( 'Default Admin Email', 'gkform' ); ?></label>
            <input class="gkf-input" type="email" id="admin_email" name="admin_email"
                   value="<?php echo esc_attr( get_option( 'gkform_admin_email', get_option( 'admin_email' ) ) ); ?>"/>
            <span class="gkf-hint">Fallback when no per-form email is configured.</span>
          </div>
          <div class="gkf-toggle-row">
            <span class="gkf-toggle-label"><?php esc_html_e( 'Enable Email Logging (global)', 'gkform' ); ?></span>
            <label class="gkf-toggle">
              <input type="checkbox" name="enable_logs" <?php checked( get_option( 'gkform_enable_logs', '1' ), '1' ); ?>/>
              <span class="gkf-toggle-track"></span>
            </label>
          </div>
        </div>
      </div>

      <!-- reCAPTCHA -->
      <div class="gkf-card">
        <div class="gkf-card-header"><h3>🔒 Google reCAPTCHA v2</h3></div>
        <div class="gkf-card-body">
          <div class="gkf-field-group">
            <label for="recaptcha_site_key"><?php esc_html_e( 'Site Key', 'gkform' ); ?></label>
            <input class="gkf-input" type="text" id="recaptcha_site_key" name="recaptcha_site_key"
                   value="<?php echo esc_attr( get_option( 'gkform_recaptcha_site_key', '' ) ); ?>"
                   placeholder="6Lc…"/>
          </div>
          <div class="gkf-field-group">
            <label for="recaptcha_secret_key"><?php esc_html_e( 'Secret Key', 'gkform' ); ?></label>
            <input class="gkf-input" type="password" id="recaptcha_secret_key" name="recaptcha_secret_key"
                   value="<?php echo esc_attr( get_option( 'gkform_recaptcha_secret_key', '' ) ); ?>"
                   placeholder="6Lc…"/>
          </div>
          <p style="font-size:.78rem;color:#9ca3af;margin:4px 0 0;">
            Get your free keys at
            <a href="https://www.google.com/recaptcha/admin" target="_blank" rel="noopener">google.com/recaptcha</a>.
            Enable per-form in the builder → Security tab.
          </p>
        </div>
      </div>

    </div>

    <div style="margin-top:20px;">
      <button type="submit" class="gkf-btn gkf-btn-primary">💾 Save Settings</button>
    </div>
  </form>

</div>
