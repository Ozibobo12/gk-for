<?php
defined( 'ABSPATH' ) || exit;

$form_id   = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
$page      = max( 1, isset( $_GET['gkf_page'] ) ? absint( $_GET['gkf_page'] ) : 1 );
$per_page  = 20;
$logs      = GKForm_DB::get_logs( [ 'per_page' => $per_page, 'page' => $page, 'form_id' => $form_id ] );
$total     = GKForm_DB::count_logs( $form_id );
$stats     = GKForm_DB::get_log_stats();
$tot_pages = max( 1, (int) ceil( $total / $per_page ) );
$forms     = GKForm_DB::get_forms();
?>
<div class="wrap gkform-wrap">

  <div class="gkf-page-header">
    <h1><span class="gkf-logo">GK</span> Email Logs</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <?php if ( $total > 0 ) : ?>
        <button id="gkf-clear-logs" class="gkf-btn gkf-btn-danger" data-form-id="<?php echo absint( $form_id ); ?>">
          🗑️ Clear <?php echo $form_id ? 'Form ' : 'All '; ?>Logs
        </button>
      <?php endif; ?>
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform' ) ); ?>" class="gkf-btn gkf-btn-ghost">← Forms</a>
    </div>
  </div>

  <!-- Stats -->
  <div class="gkf-stats-strip">
    <div class="gkf-stat-card">
      <div class="stat-value" id="gkf-log-total"><?php echo absint( $stats['total'] ); ?></div>
      <div class="stat-label">Total</div>
    </div>
    <div class="gkf-stat-card">
      <div class="stat-value" style="color:#166534"><?php echo absint( $stats['sent'] ); ?></div>
      <div class="stat-label">Sent</div>
    </div>
    <div class="gkf-stat-card">
      <div class="stat-value" style="color:var(--gkf-red,#ef4444)"><?php echo absint( $stats['failed'] ); ?></div>
      <div class="stat-label">Failed</div>
    </div>
  </div>

  <!-- Filter -->
  <div class="gkf-card" style="margin-bottom:16px;padding:12px 18px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
    <span style="font-size:.875rem;font-weight:600;color:#4b5563;">Filter by form:</span>
    <form method="get" action="" style="display:flex;gap:8px;align-items:center;">
      <input type="hidden" name="page" value="gkform-logs"/>
      <select name="form_id" class="gkf-select" style="width:auto;min-width:180px;">
        <option value="0">— All Forms —</option>
        <?php foreach ( $forms as $f ) : ?>
          <option value="<?php echo absint( $f->id ); ?>" <?php selected( $form_id, $f->id ); ?>>
            <?php echo esc_html( $f->form_name ); ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="gkf-btn gkf-btn-secondary gkf-btn-sm">Filter</button>
      <?php if ( $form_id ) : ?>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform-logs' ) ); ?>" class="gkf-btn gkf-btn-ghost gkf-btn-sm">Clear</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Table -->
  <div class="gkf-card">
    <div class="gkf-table-wrap">
      <table class="gkf-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Form</th>
            <th>From</th>
            <th>Subject</th>
            <th>Status</th>
            <th>IP</th>
            <th>Date / Time</th>
            <th>Body</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="gkf-logs-tbody">
          <?php if ( empty( $logs ) ) : ?>
            <tr class="gkf-no-results"><td colspan="9">📭 No email logs found.</td></tr>
          <?php else : ?>
            <?php foreach ( $logs as $log ) : ?>
              <tr>
                <td><span class="gkf-badge"><?php echo absint( $log->id ); ?></span></td>
                <td><?php echo esc_html( $log->form_name ); ?></td>
                <td><?php echo esc_html( $log->sender ); ?></td>
                <td><?php echo esc_html( $log->subject ); ?></td>
                <td>
                  <span class="gkf-log-status <?php echo esc_attr( $log->status ); ?>">
                    <?php echo 'sent' === $log->status ? '✓' : '✗'; ?>
                    <?php echo esc_html( $log->status ); ?>
                  </span>
                </td>
                <td style="font-size:.78rem;color:#9ca3af;"><?php echo esc_html( $log->ip_address ); ?></td>
                <td style="white-space:nowrap;font-size:.8rem;">
                  <?php echo esc_html( wp_date( get_option( 'date_format' ) . ' H:i', strtotime( $log->created_at ) ) ); ?>
                </td>
                <td>
                  <button class="gkf-log-body-toggle" data-log-id="<?php echo absint( $log->id ); ?>" data-loaded="0">View</button>
                  <div class="gkf-log-detail" style="display:none;"></div>
                </td>
                <td>
                  <button class="gkf-btn gkf-btn-danger gkf-btn-xs gkf-delete-log" data-id="<?php echo absint( $log->id ); ?>">
                    🗑️
                  </button>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if ( $tot_pages > 1 ) : ?>
      <div class="gkf-pagination" style="padding:14px;">
        <?php for ( $i = 1; $i <= $tot_pages; $i++ ) : ?>
          <a href="<?php echo esc_url( add_query_arg( [
            'page'     => 'gkform-logs',
            'form_id'  => $form_id,
            'gkf_page' => $i,
          ], admin_url( 'admin.php' ) ) ); ?>"
             class="gkf-page-btn <?php echo $i === $page ? 'active' : ''; ?>">
            <?php echo $i; ?>
          </a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </div>

</div>
