<?php
defined( 'ABSPATH' ) || exit;

$editing   = ! empty( $form );
$form_id   = $editing ? absint( $form->id ) : 0;
$form_name = $editing ? esc_attr( $form->form_name ) : '';
$settings  = $editing ? (array) json_decode( $form->settings, true ) : [];

$palette = [
  'username' => [ '👤', 'Full Name' ],
  'email'    => [ '📧', 'Email' ],
  'phone'    => [ '📞', 'Phone' ],
  'country'  => [ '🌍', 'Country' ],
  'text'     => [ '✏️', 'Text' ],
  'textarea' => [ '📝', 'Textarea' ],
  'dropdown' => [ '🔽', 'Dropdown' ],
  'radio'    => [ '⚪', 'Radio' ],
  'checkbox' => [ '☑️', 'Checkbox' ],
  'file'     => [ '📎', 'File Upload' ],
  'number'   => [ '🔢', 'Number' ],
  'url'      => [ '🔗', 'URL' ],
  'date'     => [ '📅', 'Date' ],
  'hidden'   => [ '👁️', 'Hidden' ],
];
?>
<div class="wrap gkform-wrap">

  <div class="gkf-page-header">
    <h1>
      <span class="gkf-logo">GK</span>
      <?php echo $editing ? esc_html__( 'Edit Form', 'gkform' ) : esc_html__( 'New Form', 'gkform' ); ?>
      <?php if ( $editing ) : ?>
        <span style="font-size:.9rem;color:var(--gkf-gray-400,#9ca3af);font-weight:400;">— <?php echo esc_html( $form->form_name ); ?></span>
      <?php endif; ?>
    </h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform' ) ); ?>" class="gkf-btn gkf-btn-ghost">← All Forms</a>
      <button type="button" id="gkf-save-form-btn" class="gkf-btn gkf-btn-primary">💾 Save Form</button>
    </div>
  </div>

  <input type="hidden" id="gkf-form-id" value="<?php echo absint( $form_id ); ?>"/>

  <!-- Shortcode bar (shown after first save) -->
  <div class="gkf-shortcode-result" style="<?php echo $editing ? '' : 'display:none;'; ?>">
    <span style="font-size:.875rem;font-weight:600;color:#4b5563;">Shortcode:</span>
    <span class="gkf-shortcode" id="gkf-shortcode-display"
          data-code="<?php echo $editing ? esc_attr( '[gkform id="' . $form_id . '"]' ) : ''; ?>">
      <?php echo $editing ? esc_html( '[gkform id="' . $form_id . '"]' ) : ''; ?>
    </span>
    <span style="font-size:.8rem;color:#9ca3af;">← click to copy</span>
  </div>

  <div id="gkf-builder-app">
    <div class="gkf-builder-layout">

      <!-- LEFT: Palette -->
      <div class="gkf-palette-panel">
        <div class="gkf-card">
          <div class="gkf-card-header"><h3>📦 Field Types</h3></div>
          <div class="gkf-field-types">
            <?php foreach ( $palette as $type => [ $icon, $label ] ) : ?>
              <div class="gkf-field-chip" data-type="<?php echo esc_attr( $type ); ?>" draggable="true"
                   title="<?php echo esc_attr( 'Add ' . $label ); ?>">
                <span class="chip-icon"><?php echo $icon; ?></span>
                <span><?php echo esc_html( $label ); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- CENTRE: Canvas -->
      <div>
        <div class="gkf-form-name-row">
          <input type="text" id="gkf-form-name" class="gkf-form-name-input"
                 placeholder="<?php esc_attr_e( 'Form Name — e.g. Contact Us', 'gkform' ); ?>"
                 value="<?php echo $form_name; ?>"/>
        </div>

        <div class="gkf-card">
          <div class="gkf-card-header">
            <h3>🎨 Form Canvas</h3>
            <small style="color:#9ca3af;">Drag &amp; drop to reorder · Click field to edit</small>
          </div>
          <div class="gkf-card-body" style="padding:12px;">
            <div id="gkf-drop-zone" class="gkf-drop-zone"></div>
          </div>
        </div>
      </div>

      <!-- RIGHT: Properties + Settings -->
      <div class="gkf-props-panel">

        <!-- Field Properties -->
        <div class="gkf-card" style="margin-bottom:16px;">
          <div class="gkf-card-header"><h3>⚙️ Field Properties</h3></div>
          <div class="gkf-card-body" id="gkf-props-body">
            <div class="gkf-props-empty"><span>👈</span><p>Select a field to edit its properties</p></div>
          </div>
        </div>

        <!-- Form Settings -->
        <div class="gkf-card">
          <div class="gkf-card-header"><h3>📬 Form Settings</h3></div>
          <div class="gkf-card-body gkf-tabbed">
            <div class="gkf-tabs">
              <button type="button" class="gkf-tab active" data-tab="gkf-tab-email">Email</button>
              <button type="button" class="gkf-tab" data-tab="gkf-tab-display">Display</button>
              <button type="button" class="gkf-tab" data-tab="gkf-tab-security">Security</button>
            </div>

            <!-- Email -->
            <div class="gkf-tab-pane active" id="gkf-tab-email">
              <div class="gkf-field-group">
                <label><?php esc_html_e( 'Send Emails To', 'gkform' ); ?></label>
                <input class="gkf-input" type="email" id="gkf-to-email"
                       value="<?php echo esc_attr( $settings['to_email'] ?? get_option( 'admin_email' ) ); ?>"
                       placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"/>
              </div>
              <div class="gkf-field-group">
                <label><?php esc_html_e( 'Email Subject', 'gkform' ); ?></label>
                <input class="gkf-input" type="text" id="gkf-email-subject"
                       value="<?php echo esc_attr( $settings['email_subject'] ?? 'New form submission' ); ?>"
                       placeholder="New form submission"/>
              </div>
              <div class="gkf-toggle-row">
                <span class="gkf-toggle-label"><?php esc_html_e( 'Log Emails', 'gkform' ); ?></span>
                <label class="gkf-toggle">
                  <input type="checkbox" id="gkf-enable-logs"
                         <?php checked( $settings['enable_logs'] ?? true ); ?>/>
                  <span class="gkf-toggle-track"></span>
                </label>
              </div>
            </div>

            <!-- Display -->
            <div class="gkf-tab-pane" id="gkf-tab-display">
              <div class="gkf-field-group">
                <label><?php esc_html_e( 'Submit Button Text', 'gkform' ); ?></label>
                <input class="gkf-input" type="text" id="gkf-submit-text"
                       value="<?php echo esc_attr( $settings['submit_text'] ?? 'Send Message' ); ?>"
                       placeholder="Send Message"/>
              </div>
              <div class="gkf-field-group">
                <label><?php esc_html_e( 'Success Message', 'gkform' ); ?></label>
                <textarea class="gkf-textarea" id="gkf-success-msg"
                          placeholder="Thank you! Your message has been sent."><?php
                  echo esc_textarea( $settings['success_msg'] ?? 'Thank you! Your message has been sent.' );
                ?></textarea>
              </div>
              <div class="gkf-toggle-row">
                <span class="gkf-toggle-label">
                  <?php esc_html_e( 'Show Form Title', 'gkform' ); ?>
                  <small style="display:block;font-weight:400;color:#9ca3af;font-size:.72rem;margin-top:2px;">Display the form name at the top</small>
                </span>
                <label class="gkf-toggle">
                  <input type="checkbox" id="gkf-show-title"
                         <?php checked( $settings['show_title'] ?? true ); ?>/>
                  <span class="gkf-toggle-track"></span>
                </label>
              </div>
              <div class="gkf-toggle-row">
                <span class="gkf-toggle-label">
                  <?php esc_html_e( 'Multi-Step Mode', 'gkform' ); ?>
                  <small style="display:block;font-weight:400;color:#9ca3af;font-size:.72rem;margin-top:2px;">Show one field at a time with Next / Back</small>
                </span>
                <label class="gkf-toggle">
                  <input type="checkbox" id="gkf-multi-step"
                         <?php checked( $settings['multi_step'] ?? false ); ?>/>
                  <span class="gkf-toggle-track"></span>
                </label>
              </div>
            </div>

            <!-- Security -->
            <div class="gkf-tab-pane" id="gkf-tab-security">
              <div class="gkf-toggle-row">
                <span class="gkf-toggle-label"><?php esc_html_e( 'Enable reCAPTCHA v2', 'gkform' ); ?></span>
                <label class="gkf-toggle">
                  <input type="checkbox" id="gkf-enable-captcha"
                         <?php checked( $settings['enable_captcha'] ?? false ); ?>/>
                  <span class="gkf-toggle-track"></span>
                </label>
              </div>
              <p style="font-size:.78rem;color:#9ca3af;margin-top:10px;">
                <?php esc_html_e( 'reCAPTCHA keys must be configured in', 'gkform' ); ?>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform-settings' ) ); ?>">Settings</a>.
              </p>
            </div>

          </div>
        </div>

      </div>
      <!-- /RIGHT -->

    </div>
  </div>
</div>
