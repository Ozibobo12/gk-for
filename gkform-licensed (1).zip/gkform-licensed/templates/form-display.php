<?php
/**
 * GK Form — Frontend form display template
 * Available: $form (object), $fields (array), $settings (array), $id (int)
 */
defined( 'ABSPATH' ) || exit;

$submit_text    = ! empty( $settings['submit_text'] ) ? $settings['submit_text'] : 'Send Message';
$site_key       = get_option( 'gkform_recaptcha_site_key', '' );
$has_captcha    = ! empty( $settings['enable_captcha'] ) && $site_key;
$show_title     = isset( $settings['show_title'] ) ? (bool) $settings['show_title'] : true;
$multi_step     = ! empty( $settings['multi_step'] );

/* Separate visible fields from hidden ones */
$visible_fields = array_values( array_filter( $fields, static fn( $f ) => 'hidden' !== $f['type'] ) );
$hidden_fields  = array_filter( $fields, static fn( $f ) => 'hidden' === $f['type'] );
$step_count     = count( $visible_fields );

/* Country list — static so it is allocated only once even if template is
   included multiple times (multiple [gkform] shortcodes on one page). */
static $countries = null;
if ( null === $countries ) {
    $countries = [
      'Afghanistan','Albania','Algeria','Andorra','Angola','Argentina','Armenia','Australia','Austria',
      'Azerbaijan','Bahamas','Bahrain','Bangladesh','Belarus','Belgium','Belize','Benin','Bolivia',
      'Bosnia and Herzegovina','Botswana','Brazil','Brunei','Bulgaria','Cambodia','Cameroon','Canada',
      'Chile','China','Colombia','Costa Rica','Croatia','Cuba','Cyprus','Czechia','Denmark','Ecuador',
      'Egypt','El Salvador','Estonia','Ethiopia','Finland','France','Germany','Ghana','Greece',
      'Guatemala','Haiti','Honduras','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland',
      'Israel','Italy','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Kuwait','Latvia','Lebanon',
      'Libya','Lithuania','Luxembourg','Malaysia','Mexico','Moldova','Morocco','Mozambique','Myanmar',
      'Nepal','Netherlands','New Zealand','Nicaragua','Nigeria','North Korea','Norway','Oman',
      'Pakistan','Panama','Paraguay','Peru','Philippines','Poland','Portugal','Qatar','Romania',
      'Russia','Rwanda','Saudi Arabia','Senegal','Serbia','Singapore','Slovakia','Slovenia',
      'Somalia','South Africa','South Korea','Spain','Sri Lanka','Sudan','Sweden','Switzerland',
      'Syria','Taiwan','Tanzania','Thailand','Tunisia','Turkey','Uganda','Ukraine',
      'United Arab Emirates','United Kingdom','United States','Uruguay','Uzbekistan','Venezuela',
      'Vietnam','Yemen','Zambia','Zimbabwe',
    ];
}

/**
 * Render the inner markup for a single field.
 * Wrapped in function_exists() guard so multiple [gkform] shortcodes on the
 * same page do not cause a PHP fatal "Cannot redeclare function" error.
 */
if ( ! function_exists( 'gkform_render_field' ) ) {
function gkform_render_field( array $field, array $countries, bool $wrap = true ): void {
    $fid       = esc_attr( $field['id'] );
    $label     = esc_html( $field['label'] );
    $req       = ! empty( $field['required'] );
    $ph        = esc_attr( $field['placeholder'] ?? '' );
    $width     = in_array( $field['width'] ?? 'full', [ 'half', 'full' ], true ) ? $field['width'] : 'full';
    $type      = $field['type'];
    $req_attr  = $req ? 'data-required="1"' : '';
    $req_badge = $req ? '<span class="gkf-required" aria-label="required">*</span>' : '';

    if ( $wrap ) {
        echo '<div class="gkform-field-wrap gkf-' . $width . '">';
    }

    switch ( $type ) {

        case 'country':
            echo "<label for=\"{$fid}\">{$label}{$req_badge}</label>";
            echo "<select id=\"{$fid}\" name=\"{$fid}\" {$req_attr}>";
            echo '<option value="">— Select Country —</option>';
            foreach ( $countries as $c ) {
                printf( '<option value="%s">%s</option>', esc_attr( $c ), esc_html( $c ) );
            }
            echo '</select>';
            break;

        case 'dropdown':
            echo "<label for=\"{$fid}\">{$label}{$req_badge}</label>";
            echo "<select id=\"{$fid}\" name=\"{$fid}\" {$req_attr}>";
            echo '<option value="">— Select —</option>';
            foreach ( (array) ( $field['options'] ?? [] ) as $opt ) {
                printf( '<option value="%s">%s</option>', esc_attr( $opt ), esc_html( $opt ) );
            }
            echo '</select>';
            break;

        case 'radio':
            echo "<label>{$label}{$req_badge}</label>";
            echo '<div class="gkform-radio-group" role="radiogroup">';
            foreach ( (array) ( $field['options'] ?? [] ) as $opt ) {
                echo '<label class="gkform-radio-item">';
                printf( '<input type="radio" name="%s" value="%s" %s/>', $fid, esc_attr( $opt ), $req_attr );
                echo esc_html( $opt ) . '</label>';
            }
            echo '</div>';
            break;

        case 'checkbox':
            echo "<label>{$label}{$req_badge}</label>";
            echo '<div class="gkform-checkbox-group">';
            foreach ( (array) ( $field['options'] ?? [] ) as $opt ) {
                echo '<label class="gkform-check-item">';
                printf( '<input type="checkbox" name="%s[]" value="%s"/>', $fid, esc_attr( $opt ) );
                echo esc_html( $opt ) . '</label>';
            }
            echo '</div>';
            break;

        case 'textarea':
            echo "<label for=\"{$fid}\">{$label}{$req_badge}</label>";
            printf( '<textarea id="%s" name="%s" placeholder="%s" %s></textarea>', $fid, $fid, $ph, $req_attr );
            break;

        case 'file':
            $max_mb = absint( $field['max_size'] ?? 0 );
            $accept = esc_attr( $field['accept'] ?? '' );
            $multi  = ! empty( $field['multiple'] );
            $fname  = $fid . ( $multi ? '[]' : '' );

            echo "<label>{$label}{$req_badge}</label>";
            echo '<div class="gkform-file-area" data-max-size="' . $max_mb . '">';
            echo '<input type="file" name="' . $fname . '" id="' . $fid . '"';
            if ( $accept ) echo ' accept="' . $accept . '"';
            if ( $multi )  echo ' multiple';
            echo ' ' . $req_attr . '/>';
            echo '<span class="file-icon" aria-hidden="true">📎</span>';
            echo '<p class="file-text"><strong>Click to upload</strong> or drag &amp; drop';
            if ( $max_mb > 0 ) {
                echo '<br><small>Max ' . $max_mb . ' MB';
                if ( $field['accept'] ) echo ' · ' . esc_html( $field['accept'] );
                echo '</small>';
            } elseif ( $field['accept'] ) {
                echo '<br><small>' . esc_html( $field['accept'] ) . '</small>';
            }
            echo '</p></div>';
            echo '<div class="gkform-file-list"></div>';
            break;

        default:
            $input_type = match ( $type ) {
                'email'  => 'email',
                'phone'  => 'tel',
                'number' => 'number',
                'url'    => 'url',
                'date'   => 'date',
                default  => 'text',
            };
            echo "<label for=\"{$fid}\">{$label}{$req_badge}</label>";
            printf( '<input type="%s" id="%s" name="%s" placeholder="%s" %s/>', $input_type, $fid, $fid, $ph, $req_attr );
    }

    echo '<div class="gkf-field-error" aria-live="polite"></div>';

    if ( $wrap ) {
        echo '</div>'; /* .gkform-field-wrap */
    }
} // end function gkform_render_field
} // end function_exists guard
?>
<div class="gkform-container<?php echo $multi_step ? ' gkform-is-multistep' : ''; ?>"
     id="gkform-<?php echo absint( $id ); ?>"
     data-multistep="<?php echo $multi_step ? '1' : '0'; ?>"
     data-steps="<?php echo absint( $step_count ); ?>">

  <div class="gkform-card">

    <?php if ( $show_title || ( $multi_step && $step_count > 1 ) ) : ?>
      <div class="gkform-card-header<?php echo ( ! $show_title && $multi_step ) ? ' gkform-header-slim' : ''; ?>">
        <?php if ( $show_title ) : ?>
          <h3><?php echo esc_html( $form->form_name ); ?></h3>
        <?php endif; ?>

        <?php if ( $multi_step && $step_count > 1 ) : ?>
          <div class="gkf-step-progress">
            <div class="gkf-step-info">
              <span class="gkf-step-label">Step <strong class="gkf-step-current">1</strong> of <strong><?php echo absint( $step_count ); ?></strong></span>
            </div>
            <div class="gkf-step-track" role="progressbar" aria-valuemin="1" aria-valuemax="<?php echo absint( $step_count ); ?>" aria-valuenow="1">
              <div class="gkf-step-fill" style="width:<?php echo round( 100 / $step_count ); ?>%"></div>
            </div>
            <div class="gkf-step-dots">
              <?php for ( $d = 0; $d < $step_count; $d++ ) : ?>
                <span class="gkf-dot<?php echo 0 === $d ? ' active' : ''; ?>"></span>
              <?php endfor; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="gkform-card-body">

      <!-- Alerts -->
      <div class="gkform-alert gkform-alert-success" role="alert" aria-live="polite">
        <span class="alert-icon" aria-hidden="true">✅</span>
        <span class="alert-msg"></span>
      </div>
      <div class="gkform-alert gkform-alert-error" role="alert" aria-live="assertive">
        <span class="alert-icon" aria-hidden="true">⚠️</span>
        <span class="alert-msg"></span>
      </div>

      <form class="gkform-form" novalidate enctype="multipart/form-data">
        <input type="hidden" name="form_id" value="<?php echo absint( $id ); ?>"/>

        <?php foreach ( $hidden_fields as $hf ) : ?>
          <input type="hidden" name="<?php echo esc_attr( $hf['id'] ); ?>"
                 value="<?php echo esc_attr( $hf['placeholder'] ?? '' ); ?>"/>
        <?php endforeach; ?>

        <?php if ( $multi_step && $step_count > 1 ) : ?>
          <?php /* ════ MULTI-STEP MODE ════════════════════════════════════ */ ?>
          <div class="gkf-steps-viewport">

            <?php foreach ( $visible_fields as $step_idx => $field ) :
              $is_first = 0 === $step_idx;
              $is_last  = ( $step_idx === $step_count - 1 );
            ?>
              <div class="gkf-step<?php echo $is_first ? ' gkf-step-active' : ''; ?>"
                   data-step="<?php echo $step_idx; ?>"
                   aria-hidden="<?php echo $is_first ? 'false' : 'true'; ?>">

                <div class="gkf-step-fields">
                  <?php gkform_render_field( $field, $countries ); ?>
                </div>

                <div class="gkf-step-nav">
                  <div class="gkf-step-nav-left">
                    <?php if ( ! $is_first ) : ?>
                      <button type="button" class="gkf-btn-back">← Back</button>
                    <?php endif; ?>
                  </div>

                  <div class="gkf-step-nav-right">
                    <?php if ( $is_last ) : ?>
                      <?php if ( $has_captcha ) : ?>
                        <div class="gkform-captcha-row" style="margin-bottom:14px;">
                          <div class="g-recaptcha" data-sitekey="<?php echo esc_attr( $site_key ); ?>"></div>
                        </div>
                      <?php endif; ?>
                      <button type="submit" class="gkform-submit-btn">
                        <span class="gkf-btn-spinner" aria-hidden="true"></span>
                        <span class="gkf-btn-text"><?php echo esc_html( $submit_text ); ?></span>
                      </button>
                    <?php else : ?>
                      <button type="button" class="gkf-btn-next">Next →</button>
                    <?php endif; ?>
                  </div>
                </div>

              </div><!-- /.gkf-step -->
            <?php endforeach; ?>

          </div><!-- /.gkf-steps-viewport -->

        <?php else : ?>
          <?php /* ════ NORMAL MODE ════════════════════════════════════════ */ ?>
          <div class="gkform-fields-grid">
            <?php foreach ( $visible_fields as $field ) : ?>
              <?php gkform_render_field( $field, $countries ); ?>
            <?php endforeach; ?>
          </div>

          <?php if ( $has_captcha ) : ?>
            <div class="gkform-captcha-row">
              <div class="g-recaptcha" data-sitekey="<?php echo esc_attr( $site_key ); ?>"></div>
            </div>
          <?php endif; ?>

          <div class="gkform-submit-row">
            <button type="submit" class="gkform-submit-btn">
              <span class="gkf-btn-spinner" aria-hidden="true"></span>
              <span class="gkf-btn-text"><?php echo esc_html( $submit_text ); ?></span>
            </button>
          </div>

        <?php endif; ?>

      </form>
    </div><!-- /card-body -->
  </div><!-- /card -->
</div><!-- /container -->
