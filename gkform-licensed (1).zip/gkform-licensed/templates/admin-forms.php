<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap gkform-wrap">

  <div class="gkf-page-header">
    <h1><span class="gkf-logo">GK</span> GK Form</h1>
    <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform-builder' ) ); ?>" class="gkf-btn gkf-btn-primary">
      + New Form
    </a>
  </div>

  <div class="gkf-card">
    <?php if ( empty( $forms ) ) : ?>
      <div class="gkf-empty">
        <div class="gkf-empty-icon">📋</div>
        <h3><?php esc_html_e( 'No forms yet', 'gkform' ); ?></h3>
        <p><?php esc_html_e( 'Create your first form and embed it anywhere with a shortcode.', 'gkform' ); ?></p>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform-builder' ) ); ?>" class="gkf-btn gkf-btn-primary">
          + Create First Form
        </a>
      </div>
    <?php else : ?>
      <div class="gkf-table-wrap">
        <table class="gkf-table">
          <thead>
            <tr>
              <th>#</th>
              <th><?php esc_html_e( 'Form Name', 'gkform' ); ?></th>
              <th><?php esc_html_e( 'Shortcode', 'gkform' ); ?></th>
              <th><?php esc_html_e( 'Created', 'gkform' ); ?></th>
              <th><?php esc_html_e( 'Updated', 'gkform' ); ?></th>
              <th><?php esc_html_e( 'Actions', 'gkform' ); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ( $forms as $form ) :
              $sc = '[gkform id="' . absint( $form->id ) . '"]';
            ?>
              <tr>
                <td><span class="gkf-badge"><?php echo absint( $form->id ); ?></span></td>
                <td><strong><?php echo esc_html( $form->form_name ); ?></strong></td>
                <td>
                  <span class="gkf-shortcode" data-code="<?php echo esc_attr( $sc ); ?>" title="<?php esc_attr_e( 'Click to copy', 'gkform' ); ?>">
                    <?php echo esc_html( $sc ); ?>
                  </span>
                </td>
                <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $form->created_at ) ) ); ?></td>
                <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $form->updated_at ) ) ); ?></td>
                <td>
                  <div class="actions">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform-builder&edit=' . absint( $form->id ) ) ); ?>"
                       class="gkf-btn gkf-btn-secondary gkf-btn-sm">✏️ Edit</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=gkform-logs&form_id=' . absint( $form->id ) ) ); ?>"
                       class="gkf-btn gkf-btn-ghost gkf-btn-sm">📨 Logs</a>
                    <button class="gkf-btn gkf-btn-danger gkf-btn-sm gkf-delete-form"
                            data-id="<?php echo absint( $form->id ); ?>">🗑️ Delete</button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

</div>
