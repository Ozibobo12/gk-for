/*!
 * GK Form — Frontend JS v1.3.0
 * Loaded ONLY on pages that render the [gkform] shortcode.
 *
 * Performance fixes applied:
 *  - DOM refs for progress elements cached once, not re-queried on every step
 *  - transitionend + setTimeout race guard with a boolean flag
 *  - renderFileList batches all DOM work into one innerHTML write
 *  - Dead variable `tooLarge` removed
 *  - will-change promoted via class only during active transition (see CSS)
 *  - Step navigation debounced to prevent double-click concurrent transitions
 */
/* global gkformFrontend, jQuery */
(function ($) {
  'use strict';

  $(document).ready(function () {
    $('.gkform-container').each(function () {
      var $container  = $(this);
      var isMultiStep = $container.data('multistep') === 1 ||
                        $container.data('multistep') === '1';

      if ( isMultiStep ) {
        initMultiStep( $container );
      } else {
        initNormalForm( $container );
      }
    });
  });

  /* ══════════════════════════════════════════════════════════════
     MULTI-STEP MODE
     ══════════════════════════════════════════════════════════════ */
  function initMultiStep($container) {
    var $form       = $container.find('.gkform-form');
    var $viewport   = $container.find('.gkf-steps-viewport');
    var $steps      = $viewport.find('.gkf-step');
    var $success    = $container.find('.gkform-alert-success');
    var $error      = $container.find('.gkform-alert-error');
    var totalSteps  = $steps.length;
    var currentStep = 0;
    var transitioning = false; // FIX 10/13: guard against concurrent transitions

    /* FIX 9: Cache all progress DOM references once at init */
    var $fill    = $container.find('.gkf-step-fill');
    var $counter = $container.find('.gkf-step-current');
    var $track   = $container.find('.gkf-step-track');
    var $dots    = $container.find('.gkf-dot');
    var $progress = $container.find('.gkf-step-progress');

    /* Initialise file upload UI on each step */
    $steps.each(function () { initFileUpload( $(this) ); });

    /* ── Navigate to a specific step ── */
    function goToStep(nextIdx, direction) {
      /* FIX 13: ignore calls while a transition is already in progress */
      if ( transitioning ) { return; }
      if ( nextIdx < 0 || nextIdx >= totalSteps ) { return; }

      transitioning = true;

      var $out = $steps.eq( currentStep );
      var $in  = $steps.eq( nextIdx );

      /* FIX 15: promote will-change only for the two elements actually moving */
      $out.addClass('gkf-transitioning');
      $in.addClass('gkf-transitioning');

      /* Slide out the current step */
      $out
        .addClass( direction === 'forward' ? 'gkf-step-exit-left' : 'gkf-step-exit-right' )
        .attr('aria-hidden', 'true');

      /* Prime the entering step just off-screen (no display:none yet) */
      $in.addClass( direction === 'forward' ? 'gkf-step-enter-right' : 'gkf-step-enter-left' );

      /* Force layout so the entering step starts from its off-screen position */
      /* eslint-disable-next-line no-unused-expressions */
      $in[0].offsetWidth;

      /* Slide it in */
      $in.addClass('gkf-step-active').attr('aria-hidden', 'false');

      currentStep = nextIdx;
      updateProgress(); /* FIX 9: uses cached refs — no DOM query */

      /* FIX 10/14: single cleanup path with a fired flag to prevent double-run */
      var cleanupFired = false;
      function cleanup() {
        if ( cleanupFired ) { return; }
        cleanupFired  = true;
        transitioning = false;

        $out.removeClass(
          'gkf-step-active gkf-step-exit-left gkf-step-exit-right gkf-transitioning'
        ).off('transitionend.gkfstep');
        $in.removeClass(
          'gkf-step-enter-right gkf-step-enter-left gkf-transitioning'
        );
      }

      /* Prefer transitionend for exact timing; setTimeout as hard fallback */
      $out.one('transitionend.gkfstep', cleanup);
      setTimeout(cleanup, 400); /* slightly > the 320ms CSS transition */

      /* Focus first interactive element in the new step */
      setTimeout(function () {
        $in.find('input:not([type="hidden"]), select, textarea').first().trigger('focus');
      }, 130);
    }

    /* FIX 9: updateProgress uses only cached refs — zero DOM queries */
    function updateProgress() {
      var pct = Math.round( ( ( currentStep + 1 ) / totalSteps ) * 100 );
      $fill.css('width', pct + '%');
      $counter.text( currentStep + 1 );
      $track.attr('aria-valuenow', currentStep + 1);
      $dots.each(function (i) {
        $(this)
          .toggleClass('active', i === currentStep)
          .toggleClass('done',   i < currentStep);
      });
    }

    /* Validate only the fields inside the current step */
    function validateCurrentStep() {
      return validateFields( $steps.eq( currentStep ) );
    }

    /* ── Next ── */
    $container.on('click', '.gkf-btn-next', function () {
      if ( transitioning ) { return; } /* FIX 13: debounce */
      if ( !validateCurrentStep() ) { return; }
      goToStep( currentStep + 1, 'forward' );
    });

    /* ── Back ── */
    $container.on('click', '.gkf-btn-back', function () {
      if ( transitioning ) { return; } /* FIX 13: debounce */
      clearErrors( $steps.eq( currentStep ) );
      goToStep( currentStep - 1, 'back' );
    });

    /* ── Submit (fires on last step only) ── */
    $form.on('submit', function (e) {
      e.preventDefault();
      if ( !validateCurrentStep() ) { return; }
      submitForm( $form, $success, $error, $progress );
    });
  }

  /* ══════════════════════════════════════════════════════════════
     NORMAL FORM MODE
     ══════════════════════════════════════════════════════════════ */
  function initNormalForm($container) {
    var $form    = $container.find('.gkform-form');
    var $success = $container.find('.gkform-alert-success');
    var $error   = $container.find('.gkform-alert-error');

    initFileUpload( $form );

    $form.on('submit', function (e) {
      e.preventDefault();
      if ( !validateFields( $form ) ) { return; }
      submitForm( $form, $success, $error, null );
    });
  }

  /* ══════════════════════════════════════════════════════════════
     AJAX SUBMIT
     ══════════════════════════════════════════════════════════════ */
  function submitForm($form, $success, $error, $progress) {
    var $btn      = $form.find('.gkform-submit-btn');
    var btnLabel  = $btn.find('.gkf-btn-text').text();

    $btn.prop('disabled', true).addClass('loading');
    $btn.find('.gkf-btn-text').text( gkformFrontend.strings.sending );
    $error.removeClass('visible');

    var fd = new FormData( $form[0] );
    fd.append('action', 'gkform_submit');
    fd.append('nonce',  gkformFrontend.nonce);

    $.ajax({
      url:         gkformFrontend.ajaxUrl,
      type:        'POST',
      data:        fd,
      processData: false,
      contentType: false
    })
    .done(function (r) {
      if ( r.success ) {
        $form.find(
          '.gkf-steps-viewport, .gkform-fields-grid, ' +
          '.gkform-captcha-row, .gkform-submit-row'
        ).fadeOut(180);
        if ( $progress ) { $progress.fadeOut(200); }
        $success.find('.alert-msg').html( r.data.message );
        $success.addClass('visible');
      } else {
        var msg = ( r.data && r.data.message ) ? r.data.message : gkformFrontend.strings.error;
        $error.find('.alert-msg').text( msg );
        $error.addClass('visible');
        resetBtn();
      }
    })
    .fail(function () {
      $error.find('.alert-msg').text( gkformFrontend.strings.error );
      $error.addClass('visible');
      resetBtn();
    });

    function resetBtn() {
      $btn.prop('disabled', false).removeClass('loading');
      $btn.find('.gkf-btn-text').text( btnLabel );
    }
  }

  /* ══════════════════════════════════════════════════════════════
     FIELD VALIDATION
     Validates $scope (a step div or the entire form wrapper).
     ══════════════════════════════════════════════════════════════ */
  function validateFields($scope) {
    clearErrors( $scope );
    var valid  = true;
    var $first = null;
    var s      = gkformFrontend.strings;

    /* Required check */
    $scope.find('[data-required="1"]').each(function () {
      var $el  = $(this);
      var tag  = $el.prop('tagName').toLowerCase();
      var type = ($el.attr('type') || '').toLowerCase();
      var empty;

      if ( tag === 'select' ) {
        empty = !$el.val();
      } else if ( tag === 'textarea' ) {
        empty = !$.trim( $el.val() );
      } else if ( type === 'file' ) {
        empty = !( $el[0].files && $el[0].files.length );
      } else if ( type === 'radio' ) {
        /* Radio groups: check the whole form so name-based grouping works */
        empty = !$el.closest('form').find('[name="' + $el.attr('name') + '"]:checked').length;
      } else {
        empty = !$.trim( $el.val() );
      }

      if ( empty ) {
        showFieldError( $el, s.required );
        if ( !$first ) { $first = $el; }
        valid = false;
      }
    });

    /* Email format */
    $scope.find('input[type="email"]').each(function () {
      var val = $.trim( $(this).val() );
      if ( val && !isValidEmail( val ) ) {
        showFieldError( $(this), s.invalidEmail );
        if ( !$first ) { $first = $(this); }
        valid = false;
      }
    });

    /* Client-side file size (FIX 12: removed dead `tooLarge` variable) */
    $scope.find('input[type="file"]').each(function () {
      var $input = $(this);
      var maxMb  = parseFloat(
        $input.closest('.gkform-field-wrap').find('.gkform-file-area').data('max-size')
      ) || 0;
      if ( !maxMb || !( $input[0].files && $input[0].files.length ) ) { return; }

      Array.prototype.forEach.call($input[0].files, function (file) {
        if ( file.size > maxMb * 1024 * 1024 ) {
          var msg = ( s.fileTooLarge || '"%s" exceeds %s MB.' )
            .replace('%s', file.name).replace('%s', maxMb);
          showFieldError( $input, msg );
          if ( !$first ) { $first = $input; }
          valid = false;
        }
      });
    });

    if ( $first ) { $first.trigger('focus'); }
    return valid;
  }

  function clearErrors($scope) {
    $scope.find('.gkf-error').removeClass('gkf-error');
    $scope.find('.gkf-field-error').removeClass('visible').empty();
  }

  function showFieldError($el, msg) {
    $el.addClass('gkf-error');
    $el.closest('.gkform-field-wrap').find('.gkf-field-error').text(msg).addClass('visible');
  }

  /* ══════════════════════════════════════════════════════════════
     FILE UPLOAD — drag & drop + file list
     ══════════════════════════════════════════════════════════════ */
  function initFileUpload($scope) {
    $scope.find('.gkform-file-area').each(function () {
      var $area  = $(this);
      var $input = $area.find('input[type="file"]');
      var $list  = $area.next('.gkform-file-list');
      var maxMb  = parseFloat( $area.data('max-size') ) || 0;

      $input.on('change', function () {
        renderFileList( $list, this.files, maxMb );
      });

      $area.on('dragover',  function (e) { e.preventDefault(); $area.addClass('drag-over'); });
      $area.on('dragleave', function ()  { $area.removeClass('drag-over'); });
      $area.on('drop', function (e) {
        e.preventDefault();
        $area.removeClass('drag-over');
        var dt = e.originalEvent.dataTransfer;
        if ( !dt || !dt.files || !dt.files.length ) { return; }
        try {
          var transfer = new DataTransfer();
          Array.prototype.forEach.call(dt.files, function (f) { transfer.items.add(f); });
          $input[0].files = transfer.files;
          renderFileList( $list, $input[0].files, maxMb );
        } catch (ex) {
          renderFileList( $list, dt.files, maxMb );
        }
      });
    });
  }

  /* FIX 11: batch all file items into a single string then set innerHTML once */
  function renderFileList($list, files, maxMb) {
    var html = '';
    Array.prototype.forEach.call(files, function (f) {
      var sizeMb  = ( f.size / 1024 / 1024 ).toFixed(2);
      var tooBig  = maxMb > 0 && f.size > maxMb * 1024 * 1024;
      var sizeMsg = tooBig ? sizeMb + ' MB — exceeds ' + maxMb + ' MB limit' : sizeMb + ' MB';
      html += '<div class="gkform-file-item' + ( tooBig ? ' is-too-large' : '' ) + '">' +
              '📎 ' + esc(f.name) +
              '<span class="file-size">' + sizeMsg + '</span>' +
              '</div>';
    });
    $list[0].innerHTML = html; /* single DOM write */
  }

  /* ══════════════════════════════════════════════════════════════
     UTILITIES
     ══════════════════════════════════════════════════════════════ */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function esc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

}(jQuery));
