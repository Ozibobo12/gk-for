/*!
 * GK Form — Admin JS v1.3.0
 *
 * Performance fixes applied:
 *  - base64 menu icon computed once (PHP static var, not here)
 *  - renderProps uses panel-scoped delegation, never document-level (no stacking)
 *  - Save payload built once per click
 *  - Toast: single element reused, no repeated DOM append
 *  - renderFileList: single innerHTML write (batched)
 */
/* global gkformAdmin, jQuery */
(function ($) {
  'use strict';

  /* ══════════════════════════════════════════════════════════════
     TOAST
     ══════════════════════════════════════════════════════════════ */
  var Toast = (function () {
    var $el    = null;
    var timer  = null;

    function init() {
      if ( !$el ) {
        $el = $('<div id="gkf-toast" role="status" aria-live="polite"></div>').appendTo('body');
      }
    }

    return {
      show: function (msg, type, duration) {
        init();
        type     = type     || 'default';
        duration = duration || 3200;
        clearTimeout(timer);
        $el.removeClass('show success error').text(msg);
        if ( type !== 'default' ) { $el.addClass(type); }
        $el[0].offsetHeight; /* force reflow */
        $el.addClass('show');
        timer = setTimeout(function () { $el.removeClass('show'); }, duration);
      }
    };
  }());

  /* ══════════════════════════════════════════════════════════════
     GLOBAL DELEGATED ACTIONS (forms list + logs page)
     ══════════════════════════════════════════════════════════════ */

  /* Shortcode copy */
  $(document).on('click', '.gkf-shortcode', function () {
    var code = $(this).data('code') || $.trim( $(this).text() );
    if ( navigator.clipboard ) {
      navigator.clipboard.writeText(code).then(function () {
        Toast.show( gkformAdmin.strings.copyShortcode, 'success' );
      });
    } else {
      var $tmp = $('<textarea>').val(code).appendTo('body').select();
      document.execCommand('copy');
      $tmp.remove();
      Toast.show( gkformAdmin.strings.copyShortcode, 'success' );
    }
  });

  /* Delete form row */
  $(document).on('click', '.gkf-delete-form', function (e) {
    e.preventDefault();
    if ( !window.confirm( gkformAdmin.strings.confirmDelete ) ) { return; }
    var $btn   = $(this).prop('disabled', true);
    var $row   = $btn.closest('tr');
    var formId = $btn.data('id');

    $.post( gkformAdmin.ajaxUrl, { action: 'gkform_delete_form', nonce: gkformAdmin.nonce, form_id: formId } )
      .done(function () {
        $row.fadeOut(280, function () { $(this).remove(); });
        Toast.show('Form deleted.', 'success');
      })
      .fail(function () {
        $btn.prop('disabled', false);
        Toast.show( gkformAdmin.strings.error, 'error' );
      });
  });

  /* Delete log row */
  $(document).on('click', '.gkf-delete-log', function () {
    if ( !window.confirm( gkformAdmin.strings.confirmDeleteLog ) ) { return; }
    var $btn  = $(this).prop('disabled', true);
    var $row  = $btn.closest('tr');
    var logId = $btn.data('id');

    $.post( gkformAdmin.ajaxUrl, { action: 'gkform_delete_log', nonce: gkformAdmin.nonce, log_id: logId } )
      .done(function () {
        $row.fadeOut(280, function () { $(this).remove(); });
        Toast.show('Log deleted.', 'success');
      })
      .fail(function () {
        $btn.prop('disabled', false);
        Toast.show( gkformAdmin.strings.error, 'error' );
      });
  });

  /* Clear all logs */
  $(document).on('click', '#gkf-clear-logs', function () {
    if ( !window.confirm( gkformAdmin.strings.confirmClearLogs ) ) { return; }
    var formId = $(this).data('form-id') || 0;

    $.post( gkformAdmin.ajaxUrl, { action: 'gkform_clear_logs', nonce: gkformAdmin.nonce, form_id: formId } )
      .done(function () {
        $('#gkf-logs-tbody tr').fadeOut(240, function () { $(this).remove(); });
        $('#gkf-log-total').text('0');
        Toast.show('Logs cleared.', 'success');
      });
  });

  /* Log body expand/collapse — lazy-loads body on first click via AJAX */
  $(document).on('click', '.gkf-log-body-toggle', function () {
    var $btn    = $(this);
    var $detail = $btn.siblings('.gkf-log-detail');
    var logId   = $btn.data('log-id');
    var loaded  = $btn.data('loaded');

    if ( !loaded ) {
      $btn.text('Loading…').prop('disabled', true);
      $.post( gkformAdmin.ajaxUrl, {
        action:  'gkform_get_log_body',
        nonce:   gkformAdmin.nonce,
        log_id:  logId
      })
      .done(function (r) {
        if ( r.success ) {
          $detail.html( r.data.body );
          $btn.data('loaded', 1);
        } else {
          $detail.text('Could not load email body.');
        }
        $btn.prop('disabled', false);
        $detail.slideDown(180);
        $btn.text('Hide');
      })
      .fail(function () {
        $detail.text('Error loading content.');
        $btn.prop('disabled', false).text('View');
      });
    } else {
      $detail.slideToggle(180);
      $btn.text( $detail.is(':visible') ? 'Hide' : 'View' );
    }
  });

  /* Settings tabs */
  $(document).on('click', '.gkf-tab', function () {
    var target = $(this).data('tab');
    $(this).siblings('.gkf-tab').removeClass('active');
    $(this).addClass('active');
    $(this).closest('.gkf-tabbed').find('.gkf-tab-pane').removeClass('active');
    $( '#' + target ).addClass('active');
  });

  /* ══════════════════════════════════════════════════════════════
     FORM BUILDER — only initialises on the builder page
     ══════════════════════════════════════════════════════════════ */
  if ( !$('#gkf-builder-app').length ) { return; }

  /* ── State ── */
  var State = {
    fields:     [],
    selectedId: null,
    formId:     parseInt( $('#gkf-form-id').val(), 10 ) || 0,
    counter:    0,

    addField: function (type) {
      var meta = FieldMeta[type] || { label: type, placeholder: '' };
      var id   = 'gkf_' + type + '_' + (++this.counter);
      var field = {
        id:          id,
        type:        type,
        label:       meta.label       || type,
        placeholder: meta.placeholder || '',
        required:    false,
        options:     ( meta.options || [] ).slice(),
        multiple:    meta.multiple || false,
        accept:      meta.accept   || '',
        max_size:    0,
        width:       'full'
      };
      this.fields.push(field);
      return field;
    },

    getField: function (id) {
      for ( var i = 0; i < this.fields.length; i++ ) {
        if ( this.fields[i].id === id ) { return this.fields[i]; }
      }
      return null;
    },

    removeField: function (id) {
      this.fields = this.fields.filter(function (f) { return f.id !== id; });
      if ( this.selectedId === id ) { this.selectedId = null; }
    },

    moveField: function (fromIdx, toIdx) {
      var item = this.fields.splice(fromIdx, 1)[0];
      this.fields.splice(toIdx, 0, item);
    }
  };

  var FieldMeta = {
    username: { label: 'Full Name',       placeholder: 'John Doe' },
    email:    { label: 'Email Address',   placeholder: 'john@example.com' },
    phone:    { label: 'Phone Number',    placeholder: '+1 (555) 000-0000' },
    country:  { label: 'Country',         placeholder: '' },
    text:     { label: 'Text Field',      placeholder: 'Enter text...' },
    textarea: { label: 'Message',         placeholder: 'Write your message here...' },
    dropdown: { label: 'Dropdown',        options: ['Option 1', 'Option 2'] },
    radio:    { label: 'Gender',          options: ['Male', 'Female', 'Other'] },
    checkbox: { label: 'Checkboxes',      options: ['Option 1', 'Option 2'] },
    file:     { label: 'File Upload',     accept: '', multiple: false, max_size: 0 },
    number:   { label: 'Number',          placeholder: '0' },
    url:      { label: 'Website URL',     placeholder: 'https://' },
    date:     { label: 'Date',            placeholder: '' },
    hidden:   { label: 'Hidden Field',    placeholder: '' }
  };

  var FieldIcons = {
    username: '👤', email: '📧', phone: '📞', country: '🌍',
    text: '✏️', textarea: '📝', dropdown: '🔽', radio: '⚪',
    checkbox: '☑️', file: '📎', number: '🔢', url: '🔗',
    date: '📅', hidden: '👁️'
  };

  /* ── Load existing form for edit mode ── */
  (function loadExistingForm() {
    var editId = parseInt( $('#gkf-form-id').val(), 10 );
    if ( !editId ) { return; }

    $.post( gkformAdmin.ajaxUrl, {
      action:  'gkform_get_form',
      nonce:   gkformAdmin.nonce,
      form_id: editId
    })
    .done(function (r) {
      if ( !r.success ) { return; }
      var form = r.data;

      $('#gkf-form-name').val( form.form_name || '' );
      State.formId  = parseInt( form.id, 10 ) || 0;
      State.fields  = Array.isArray( form.form_fields ) ? form.form_fields : [];
      State.counter = State.fields.length;

      /* Backfill max_size for forms saved before that field existed */
      State.fields.forEach(function (f) {
        if ( typeof f.max_size === 'undefined' ) { f.max_size = 0; }
      });

      var s = form.settings || {};
      $('#gkf-to-email').val( s.to_email || '' );
      $('#gkf-email-subject').val( s.email_subject || '' );
      $('#gkf-submit-text').val( s.submit_text || '' );
      $('#gkf-success-msg').val( s.success_msg || '' );
      $('#gkf-enable-captcha').prop('checked', !!s.enable_captcha);
      $('#gkf-enable-logs').prop('checked',    s.enable_logs !== false);
      $('#gkf-show-title').prop('checked',     s.show_title  !== false);
      $('#gkf-multi-step').prop('checked',     !!s.multi_step);

      renderCanvas();
    });
  }());

  /* ══════════════════════════════════════════════════════════════
     DRAG AND DROP
     ══════════════════════════════════════════════════════════════ */
  var dnd = { type: null, fieldId: null, fromCanvas: false, overIdx: null };

  $(document).on('dragstart', '.gkf-field-chip', function (e) {
    dnd.type       = $(this).data('type');
    dnd.fromCanvas = false;
    e.originalEvent.dataTransfer.effectAllowed = 'copy';
  });

  $(document).on('dragstart', '.gkf-field-card', function (e) {
    dnd.fieldId    = $(this).data('field-id');
    dnd.fromCanvas = true;
    e.originalEvent.dataTransfer.effectAllowed = 'move';
    $(this).addClass('drag-ghost');
    e.stopPropagation();
  });

  $(document).on('dragend', '.gkf-field-card', function () {
    $(this).removeClass('drag-ghost');
    dnd.fieldId = null;
  });

  var $zone = $('#gkf-drop-zone');

  $zone.on('dragover', function (e) {
    e.preventDefault();
    $(this).addClass('drag-over');
    if ( dnd.fromCanvas ) {
      var cards  = $(this).find('.gkf-field-card');
      var mouseY = e.originalEvent.clientY;
      var idx    = cards.length;
      cards.each(function (i) {
        var r = this.getBoundingClientRect();
        if ( mouseY < r.top + r.height / 2 ) { idx = i; return false; }
      });
      dnd.overIdx = idx;
    }
  });

  $zone.on('dragleave', function () { $(this).removeClass('drag-over'); });

  $zone.on('drop', function (e) {
    e.preventDefault();
    $(this).removeClass('drag-over');

    if ( dnd.fromCanvas && dnd.fieldId ) {
      var fromIdx = -1;
      State.fields.forEach(function (f, i) { if ( f.id === dnd.fieldId ) { fromIdx = i; } });
      var toIdx = dnd.overIdx !== null ? dnd.overIdx : State.fields.length;
      if ( fromIdx !== -1 && toIdx !== fromIdx ) {
        if ( toIdx > fromIdx ) { toIdx--; }
        State.moveField(fromIdx, toIdx);
        renderCanvas();
      }
    } else if ( dnd.type ) {
      var newField = State.addField( dnd.type );
      renderCanvas();
      selectField( newField.id );
      dnd.type = null;
    }
  });

  /* Click chip adds field */
  $(document).on('click', '.gkf-field-chip', function () {
    var f = State.addField( $(this).data('type') );
    renderCanvas();
    selectField( f.id );
  });

  /* ══════════════════════════════════════════════════════════════
     CANVAS RENDERING
     ══════════════════════════════════════════════════════════════ */
  function renderCanvas() {
    /* Build full HTML string, then set innerHTML once — avoids N separate DOM writes */
    if ( !State.fields.length ) {
      $zone[0].innerHTML =
        '<div class="gkf-drop-placeholder">' +
        '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">' +
        '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M9 21V9"/>' +
        '</svg><p>Drag fields here or click a field type to add</p></div>';
      return;
    }

    var html = '';
    State.fields.forEach(function (field) {
      var isActive = State.selectedId === field.id;
      var icon     = FieldIcons[field.type] || '📋';
      var reqBadge = field.required ? '<span class="gkf-req-badge" title="Required">*</span>' : '';

      html +=
        '<div class="gkf-field-card' + ( isActive ? ' is-active' : '' ) +
        '" data-field-id="' + esc(field.id) + '" draggable="true">' +
          '<div class="gkf-field-card-header">' +
            '<span class="drag-handle" title="Drag to reorder">⠿</span>' +
            '<span class="field-type-badge">' + esc(field.type) + '</span>' +
            '<span class="field-label-preview">' + icon + ' ' + esc(field.label) + reqBadge + '</span>' +
            '<div class="field-actions">' +
              '<button type="button" class="edit-btn" data-id="' + esc(field.id) + '" title="Edit">✏️</button>' +
              '<button type="button" class="delete-btn" data-id="' + esc(field.id) + '" title="Delete">🗑️</button>' +
            '</div>' +
          '</div>' +
        '</div>';
    });

    $zone[0].innerHTML = html; /* single DOM write */
  }

  /* ══════════════════════════════════════════════════════════════
     FIELD SELECTION
     ══════════════════════════════════════════════════════════════ */
  function selectField(id) {
    State.selectedId = id;
    renderCanvas();
    renderProps(id);
  }

  $zone.on('click', '.gkf-field-card', function (e) {
    if ( $(e.target).closest('.field-actions').length ) { return; }
    selectField( $(this).data('field-id') );
  });

  $zone.on('click', '.edit-btn', function (e) {
    e.stopPropagation();
    selectField( $(this).data('id') );
  });

  $zone.on('click', '.delete-btn', function (e) {
    e.stopPropagation();
    State.removeField( $(this).data('id') );
    renderCanvas();
    renderProps( State.selectedId );
  });

  /* ══════════════════════════════════════════════════════════════
     PROPERTIES PANEL
     All events bound to panel-scoped elements — destroyed with
     innerHTML replacement, so zero stacking possible.
     ══════════════════════════════════════════════════════════════ */
  function renderProps(id) {
    var $panel = $('#gkf-props-body');
    var field  = id ? State.getField(id) : null;

    if ( !field ) {
      $panel[0].innerHTML =
        '<div class="gkf-props-empty"><span>👈</span>' +
        '<p>Select a field to edit its properties</p></div>';
      return;
    }

    var isFile       = field.type === 'file';
    var isHidden     = field.type === 'hidden';
    var needsOptions = ['dropdown','radio','checkbox'].indexOf(field.type) !== -1;
    var hasPlaceholder = ['radio','checkbox','dropdown','file','date','hidden'].indexOf(field.type) === -1;

    /* Options list */
    var optHtml = '';
    if ( needsOptions ) {
      var rows = field.options.map(function (opt, i) {
        return '<div class="gkf-option-row">' +
          '<input class="gkf-input gkf-opt-val" data-idx="' + i + '" type="text"' +
          ' value="' + escAttr(opt) + '" placeholder="Option ' + (i+1) + '"/>' +
          '<button type="button" class="gkf-remove-opt" data-idx="' + i + '" title="Remove">✕</button>' +
          '</div>';
      }).join('');
      optHtml =
        '<div class="gkf-field-group"><label>Options</label>' +
        '<div class="gkf-options-list">' + rows + '</div>' +
        '<button type="button" class="gkf-btn gkf-btn-secondary gkf-btn-sm gkf-add-opt"' +
        ' style="margin-top:8px">+ Add Option</button></div>';
    }

    /* File-specific controls */
    var fileHtml = '';
    if ( isFile ) {
      fileHtml =
        '<div class="gkf-field-group"><label>Accepted File Types</label>' +
        '<input class="gkf-input" id="gkf-prop-accept" type="text"' +
        ' value="' + escAttr(field.accept) + '" placeholder="image/*,.pdf,.docx"/>' +
        '<small class="gkf-hint">Comma-separated MIME types or extensions</small></div>' +
        '<div class="gkf-field-group"><label>Max File Size (MB)' +
        ' <small class="gkf-hint">0 = no limit</small></label>' +
        '<input class="gkf-input" id="gkf-prop-maxsize" type="number" min="0" max="999"' +
        ' value="' + (field.max_size || 0) + '"/></div>' +
        '<div class="gkf-toggle-row"><span class="gkf-toggle-label">Allow multiple files</span>' +
        '<label class="gkf-toggle"><input type="checkbox" id="gkf-prop-multiple"' +
        ( field.multiple ? ' checked' : '' ) + '/>' +
        '<span class="gkf-toggle-track"></span></label></div>';
    }

    /* Required toggle */
    var reqHtml = '';
    if ( !isHidden ) {
      reqHtml =
        '<div class="gkf-toggle-row"><span class="gkf-toggle-label">Required field</span>' +
        '<label class="gkf-toggle"><input type="checkbox" id="gkf-prop-required"' +
        ( field.required ? ' checked' : '' ) + '/>' +
        '<span class="gkf-toggle-track"></span></label></div>';
    }

    /* Write panel HTML in one shot */
    $panel[0].innerHTML =
      '<div class="gkf-field-group"><label>Label</label>' +
      '<input class="gkf-input" id="gkf-prop-label" type="text" value="' + escAttr(field.label) + '"/></div>' +
      ( hasPlaceholder
        ? '<div class="gkf-field-group"><label>Placeholder</label>' +
          '<input class="gkf-input" id="gkf-prop-placeholder" type="text" value="' + escAttr(field.placeholder) + '"/></div>'
        : '' ) +
      fileHtml + optHtml +
      '<div class="gkf-field-group"><label>Column Width</label>' +
      '<div class="gkf-width-selector">' +
      '<div class="gkf-width-opt' + ( field.width === 'full' ? ' active' : '' ) + '" data-w="full">Full width</div>' +
      '<div class="gkf-width-opt' + ( field.width === 'half' ? ' active' : '' ) + '" data-w="half">Half width</div>' +
      '</div></div>' +
      reqHtml;

    /* ── Bind events directly to the fresh elements (no document delegation, no stacking) ── */
    $panel.find('#gkf-prop-label').on('input', function () {
      field.label = $(this).val();
      renderCanvas(); /* live update in canvas */
    });
    $panel.find('#gkf-prop-placeholder').on('input', function () { field.placeholder = $(this).val(); });
    $panel.find('#gkf-prop-required').on('change', function () {
      field.required = this.checked;
      renderCanvas(); /* update * badge */
    });
    $panel.find('#gkf-prop-multiple').on('change', function () { field.multiple = this.checked; });
    $panel.find('#gkf-prop-accept').on('input', function () { field.accept = $(this).val(); });
    $panel.find('#gkf-prop-maxsize').on('input', function () {
      field.max_size = Math.max(0, parseInt($(this).val(), 10) || 0);
    });

    /* Options — scoped to $panel, not document */
    $panel.find('.gkf-options-list').on('input', '.gkf-opt-val', function () {
      field.options[ parseInt($(this).data('idx'), 10) ] = $(this).val();
    });
    $panel.find('.gkf-add-opt').on('click', function () {
      field.options.push('New option');
      renderProps(id);
    });
    $panel.find('.gkf-options-list').on('click', '.gkf-remove-opt', function () {
      field.options.splice( parseInt($(this).data('idx'), 10), 1 );
      renderProps(id);
    });
    $panel.find('.gkf-width-selector').on('click', '.gkf-width-opt', function () {
      field.width = $(this).data('w');
      $(this).siblings().removeClass('active');
      $(this).addClass('active');
    });
  }

  /* ══════════════════════════════════════════════════════════════
     SAVE FORM
     ══════════════════════════════════════════════════════════════ */
  $('#gkf-save-form-btn').on('click', function () {
    var name = $.trim( $('#gkf-form-name').val() );
    if ( !name ) {
      Toast.show( gkformAdmin.strings.fieldRequired, 'error' );
      $('#gkf-form-name').trigger('focus');
      return;
    }

    var $btn = $(this).prop('disabled', true).html('<span class="gkf-spinner"></span> Saving…');

    /* Build payload object once */
    var payload = {
      id:          State.formId,
      form_name:   name,
      form_fields: State.fields,
      settings: {
        to_email:       $.trim( $('#gkf-to-email').val() ),
        email_subject:  $.trim( $('#gkf-email-subject').val() ),
        submit_text:    $.trim( $('#gkf-submit-text').val() )    || 'Send Message',
        success_msg:    $.trim( $('#gkf-success-msg').val() )    || 'Thank you! Your message has been sent.',
        enable_captcha: $('#gkf-enable-captcha').is(':checked'),
        enable_logs:    $('#gkf-enable-logs').is(':checked'),
        show_title:     $('#gkf-show-title').is(':checked'),
        multi_step:     $('#gkf-multi-step').is(':checked')
      }
    };

    $.post( gkformAdmin.ajaxUrl, {
      action:    'gkform_save_form',
      nonce:     gkformAdmin.nonce,
      form_data: JSON.stringify(payload)
    })
    .done(function (r) {
      if ( !r.success ) {
        Toast.show( (r.data && r.data.message) || gkformAdmin.strings.error, 'error' );
        return;
      }
      State.formId = parseInt(r.data.id, 10);
      $('#gkf-form-id').val(State.formId);

      var sc = r.data.shortcode;
      $('#gkf-shortcode-display').text(sc).attr('data-code', sc)
        .closest('.gkf-shortcode-result').show();

      Toast.show( gkformAdmin.strings.saved, 'success' );
    })
    .fail(function (xhr) {
      var msg = gkformAdmin.strings.error;
      try {
        var resp = JSON.parse(xhr.responseText);
        if ( resp && resp.data && resp.data.message ) { msg = resp.data.message; }
      } catch (ex) { /* ignore parse error */ }
      Toast.show(msg, 'error');
    })
    .always(function () {
      $btn.prop('disabled', false).html('💾 Save Form');
    });
  });

  /* ══════════════════════════════════════════════════════════════
     UTILITIES
     ══════════════════════════════════════════════════════════════ */
  function esc(str) {
    return String(str)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function escAttr(str) {
    return String(str).replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

}(jQuery));
