<?php
defined( 'ABSPATH' ) || exit;

class GKForm_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_notices',         [ $this, 'admin_notices' ] );

        // AJAX handlers (admin-only — logged-in users only)
        $ajax_actions = [
            'gkform_save_form',
            'gkform_delete_form',
            'gkform_get_form',
            'gkform_delete_log',
            'gkform_clear_logs',
            'gkform_get_log_body',
        ];
        foreach ( $ajax_actions as $action ) {
            $method = 'ajax_' . str_replace( 'gkform_', '', $action );
            add_action( 'wp_ajax_' . $action, [ $this, $method ] );
        }
    }

    // ── Menu ──────────────────────────────────────────────────────────────────

    public function register_menu(): void {
        // static: base64_encode runs once per request, not per call
        static $icon = null;
        if ( null === $icon ) {
            $icon = 'data:image/svg+xml;base64,' . base64_encode(
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white">'
                . '<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z'
                . 'M9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>'
            );
        }

        add_menu_page(
            __( 'GK Form', 'gkform' ),
            __( 'GK Form', 'gkform' ),
            'manage_options',
            'gkform',
            [ $this, 'page_forms' ],
            $icon,
            30
        );

        add_submenu_page( 'gkform', __( 'All Forms', 'gkform' ),    __( 'All Forms', 'gkform' ),    'manage_options', 'gkform',          [ $this, 'page_forms' ] );
        add_submenu_page( 'gkform', __( 'Add New Form', 'gkform' ),  __( 'Add New Form', 'gkform' ),  'manage_options', 'gkform-builder',  [ $this, 'page_builder' ] );
        add_submenu_page( 'gkform', __( 'Email Logs', 'gkform' ),    __( 'Email Logs', 'gkform' ),    'manage_options', 'gkform-logs',     [ $this, 'page_logs' ] );
        add_submenu_page( 'gkform', __( 'Settings', 'gkform' ),      __( 'Settings', 'gkform' ),      'manage_options', 'gkform-settings', [ $this, 'page_settings' ] );
    }

    // ── Asset enqueue ─────────────────────────────────────────────────────────

    public function enqueue_assets( string $hook ): void {
        $allowed = [
            'toplevel_page_gkform',
            'gk-form_page_gkform-builder',
            'gk-form_page_gkform-logs',
            'gk-form_page_gkform-settings',
        ];

        if ( ! in_array( $hook, $allowed, true ) ) {
            return;
        }

        wp_enqueue_style(
            'gkform-admin',
            GKFORM_URL . 'assets/css/admin.css',
            [],
            GKFORM_VERSION
        );

        // Load in footer to avoid render-blocking
        wp_enqueue_script(
            'gkform-admin',
            GKFORM_URL . 'assets/js/admin.js',
            [ 'jquery' ],
            GKFORM_VERSION,
            true  // footer = true
        );

        wp_localize_script( 'gkform-admin', 'gkformAdmin', [
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'gkform_admin_nonce' ),
            'strings' => [
                'confirmDelete'    => __( 'Delete this form? This cannot be undone.', 'gkform' ),
                'confirmDeleteLog' => __( 'Delete this log entry?', 'gkform' ),
                'confirmClearLogs' => __( 'Clear all logs? This cannot be undone.', 'gkform' ),
                'saved'            => __( 'Form saved successfully!', 'gkform' ),
                'error'            => __( 'Something went wrong. Please try again.', 'gkform' ),
                'fieldRequired'    => __( 'Please enter a form name.', 'gkform' ),
                'copyShortcode'    => __( 'Shortcode copied!', 'gkform' ),
                'noFields'         => __( 'Add at least one field before saving.', 'gkform' ),
            ],
        ] );
    }

    // ── Pages ─────────────────────────────────────────────────────────────────

    public function page_forms(): void {
        $forms = GKForm_DB::get_forms();
        include GKFORM_DIR . 'templates/admin-forms.php';
    }

    public function page_builder(): void {
        $form_id = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;
        $form    = $form_id ? GKForm_DB::get_form( $form_id ) : null;
        include GKFORM_DIR . 'templates/admin-builder.php';
    }

    public function page_logs(): void {
        include GKFORM_DIR . 'templates/admin-logs.php';
    }

    public function page_settings(): void {
        if ( isset( $_POST['gkform_save_settings'] ) && check_admin_referer( 'gkform_settings' ) ) {
            update_option( 'gkform_recaptcha_site_key',   sanitize_text_field( $_POST['recaptcha_site_key']   ?? '' ) );
            update_option( 'gkform_recaptcha_secret_key', sanitize_text_field( $_POST['recaptcha_secret_key'] ?? '' ) );
            update_option( 'gkform_enable_logs',          isset( $_POST['enable_logs'] ) ? '1' : '0' );
            update_option( 'gkform_admin_email',          sanitize_email( $_POST['admin_email'] ?? get_option( 'admin_email' ) ) );
            add_settings_error( 'gkform_settings', 'saved', __( 'Settings saved.', 'gkform' ), 'success' );
        }
        include GKFORM_DIR . 'templates/admin-settings.php';
    }

    public function admin_notices(): void {
        settings_errors( 'gkform_settings' );
    }

    // ── Auth helper ───────────────────────────────────────────────────────────

    private function verify_nonce(): void {
        if ( ! current_user_can( 'manage_options' )
            || ! check_ajax_referer( 'gkform_admin_nonce', 'nonce', false )
        ) {
            wp_send_json_error( [ 'message' => __( 'Unauthorised.', 'gkform' ) ], 403 );
        }
    }

    // ── AJAX: save form ───────────────────────────────────────────────────────

    public function ajax_save_form(): void {
        $this->verify_nonce();

        // Decode posted JSON
        $raw  = isset( $_POST['form_data'] ) ? wp_unslash( $_POST['form_data'] ) : '{}'; // phpcs:ignore
        $data = json_decode( $raw, true );

        if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid form data received.', 'gkform' ) ] );
        }

        $form_name = sanitize_text_field( $data['form_name'] ?? '' );
        if ( '' === $form_name ) {
            wp_send_json_error( [ 'message' => __( 'Form name is required.', 'gkform' ) ] );
        }

        // Sanitise each field
        $fields = [];
        foreach ( (array) ( $data['form_fields'] ?? [] ) as $raw_field ) {
            if ( ! is_array( $raw_field ) ) {
                continue;
            }
            $fields[] = [
                'id'          => sanitize_key( $raw_field['id'] ?? ( 'gkf_' . wp_rand() ) ),
                'type'        => sanitize_key( $raw_field['type'] ?? 'text' ),
                'label'       => sanitize_text_field( $raw_field['label'] ?? '' ),
                'placeholder' => sanitize_text_field( $raw_field['placeholder'] ?? '' ),
                'required'    => (bool) ( $raw_field['required'] ?? false ),
                'options'     => array_map( 'sanitize_text_field', (array) ( $raw_field['options'] ?? [] ) ),
                'multiple'    => (bool) ( $raw_field['multiple'] ?? false ),
                'accept'      => sanitize_text_field( $raw_field['accept'] ?? '' ),
                'max_size'    => absint( $raw_field['max_size'] ?? 0 ),  // MB, 0 = no limit
                'width'       => in_array( $raw_field['width'] ?? 'full', [ 'full', 'half' ], true )
                                    ? $raw_field['width'] : 'full',
            ];
        }

        // Sanitise settings
        $raw_s    = is_array( $data['settings'] ?? null ) ? $data['settings'] : [];
        $settings = [
            'submit_text'    => sanitize_text_field( $raw_s['submit_text']    ?? 'Send Message' ),
            'success_msg'    => sanitize_textarea_field( $raw_s['success_msg'] ?? 'Thank you! Your message has been sent.' ),
            'to_email'       => sanitize_email( $raw_s['to_email']       ?? get_option( 'admin_email' ) ),
            'email_subject'  => sanitize_text_field( $raw_s['email_subject']  ?? 'New form submission' ),
            'enable_captcha' => (bool) ( $raw_s['enable_captcha'] ?? false ),
            'enable_logs'    => isset( $raw_s['enable_logs'] ) ? (bool) $raw_s['enable_logs'] : true,
            'show_title'     => isset( $raw_s['show_title'] )  ? (bool) $raw_s['show_title']  : true,
            'multi_step'     => (bool) ( $raw_s['multi_step']  ?? false ),
        ];

        $saved_id = GKForm_DB::save_form( [
            'id'          => absint( $data['id'] ?? 0 ),
            'form_name'   => $form_name,
            'form_fields' => $fields,
            'settings'    => $settings,
        ] );

        if ( ! $saved_id ) {
            global $wpdb;
            wp_send_json_error( [
                'message' => __( 'Could not save form. Database error.', 'gkform' ),
                'db_error'=> $wpdb->last_error,
            ] );
        }

        wp_send_json_success( [
            'id'        => $saved_id,
            'shortcode' => '[gkform id="' . $saved_id . '"]',
            'message'   => __( 'Form saved successfully!', 'gkform' ),
        ] );
    }

    // ── AJAX: delete form ─────────────────────────────────────────────────────

    public function ajax_delete_form(): void {
        $this->verify_nonce();
        GKForm_DB::delete_form( absint( $_POST['form_id'] ?? 0 ) );
        wp_send_json_success();
    }

    // ── AJAX: get form (for builder edit mode) ────────────────────────────────

    public function ajax_get_form(): void {
        $this->verify_nonce();
        $form = GKForm_DB::get_form( absint( $_POST['form_id'] ?? 0 ) );

        if ( ! $form ) {
            wp_send_json_error( [ 'message' => __( 'Form not found.', 'gkform' ) ] );
        }

        // Parse JSON fields for JS consumption
        $form->form_fields = json_decode( $form->form_fields, true ) ?: [];
        $form->settings    = json_decode( $form->settings, true ) ?: [];

        wp_send_json_success( $form );
    }

    // ── AJAX: delete log ──────────────────────────────────────────────────────

    public function ajax_delete_log(): void {
        $this->verify_nonce();
        GKForm_DB::delete_log( absint( $_POST['log_id'] ?? 0 ) );
        wp_send_json_success();
    }

    // ── AJAX: clear logs ──────────────────────────────────────────────────────

    public function ajax_clear_logs(): void {
        $this->verify_nonce();
        GKForm_DB::clear_logs( absint( $_POST['form_id'] ?? 0 ) );
        wp_send_json_success();
    }

    // ── AJAX: fetch single log body on demand ─────────────────────────────────
    // Body column is excluded from the list query (fixes SELECT * over-fetch).
    // JS calls this lazily only when the user clicks "View".

    public function ajax_get_log_body(): void {
        $this->verify_nonce();
        $id   = absint( $_POST['log_id'] ?? 0 );
        $body = $id ? GKForm_DB::get_log_body( $id ) : '';
        wp_send_json_success( [ 'body' => $body ] );
    }
}
