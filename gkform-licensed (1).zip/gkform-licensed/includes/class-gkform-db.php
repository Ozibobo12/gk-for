<?php
defined( 'ABSPATH' ) || exit;

class GKForm_DB {

    // ── Schema ────────────────────────────────────────────────────────────────

    public static function install(): void {
        global $wpdb;

        // dbDelta requires: no IF NOT EXISTS, 2-space indent, PRIMARY KEY on its own line,
        // no trailing comma on last column, and each statement ended with semicolon inside
        // the heredoc — NOT as separate statements.
        $charset = $wpdb->get_charset_collate();
        $forms   = $wpdb->prefix . 'gkform_forms';
        $logs    = $wpdb->prefix . 'gkform_logs';

        // NOTE: dbDelta needs very specific formatting — each field on its own line,
        // two spaces before field names, and PRIMARY KEY on its own line.
        $sql_forms = "CREATE TABLE {$forms} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  form_name varchar(191) NOT NULL DEFAULT '',
  form_fields longtext NOT NULL,
  settings longtext NOT NULL,
  created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (id)
) {$charset};";

        $sql_logs = "CREATE TABLE {$logs} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  form_id bigint(20) unsigned NOT NULL DEFAULT 0,
  form_name varchar(191) NOT NULL DEFAULT '',
  sender varchar(191) NOT NULL DEFAULT '',
  subject varchar(255) NOT NULL DEFAULT '',
  body longtext NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'sent',
  ip_address varchar(45) NOT NULL DEFAULT '',
  created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (id),
  KEY form_id (form_id)
) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql_forms );
        dbDelta( $sql_logs );

        update_option( 'gkform_db_version', GKFORM_DB_VERSION );
    }

    public static function maybe_upgrade(): void {
        if ( get_option( 'gkform_db_version' ) !== GKFORM_DB_VERSION ) {
            self::install();
        }
    }

    // ── Forms ─────────────────────────────────────────────────────────────────

    /**
     * @return object[]
     */
    public static function get_forms(): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (array) $wpdb->get_results(
            "SELECT id, form_name, created_at, updated_at FROM {$wpdb->prefix}gkform_forms ORDER BY id DESC"
        );
    }

    public static function get_form( int $id ): ?object {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gkform_forms WHERE id = %d LIMIT 1",
            $id
        ) );
        return $row ?: null;
    }

    /**
     * Insert or update a form. Returns the form ID.
     *
     * @param array $data {
     *   int    $id          0 for insert, positive integer for update
     *   string $form_name
     *   array  $form_fields
     *   array  $settings
     * }
     */
    public static function save_form( array $data ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'gkform_forms';
        $now   = current_time( 'mysql' );

        $payload = [
            'form_name'   => sanitize_text_field( $data['form_name'] ),
            'form_fields' => wp_json_encode( $data['form_fields'] ),
            'settings'    => wp_json_encode( $data['settings'] ),
            'updated_at'  => $now,
        ];
        $formats = [ '%s', '%s', '%s', '%s' ];

        $id = absint( $data['id'] ?? 0 );

        if ( $id > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $result = $wpdb->update( $table, $payload, [ 'id' => $id ], $formats, [ '%d' ] );
            return ( false !== $result ) ? $id : 0;
        }

        $payload['created_at'] = $now;
        $formats[]             = '%s';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->insert( $table, $payload, $formats );
        return (int) $wpdb->insert_id;
    }

    public static function delete_form( int $id ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->delete( $wpdb->prefix . 'gkform_forms', [ 'id' => $id ], [ '%d' ] );
    }

    // ── Logs ──────────────────────────────────────────────────────────────────

    public static function insert_log( array $data ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->insert(
            $wpdb->prefix . 'gkform_logs',
            [
                'form_id'    => absint( $data['form_id']    ?? 0 ),
                'form_name'  => sanitize_text_field( $data['form_name']  ?? '' ),
                'sender'     => sanitize_text_field( $data['sender']     ?? '' ),
                'subject'    => sanitize_text_field( $data['subject']    ?? '' ),
                // Body is HTML we constructed ourselves — no need for expensive kses parse.
                // wp_unslash so magic-quote escaping doesn't corrupt the HTML.
                'body'       => wp_unslash( $data['body'] ?? '' ),
                'status'     => sanitize_key( $data['status']     ?? 'sent' ),
                'ip_address' => sanitize_text_field( $data['ip_address'] ?? '' ),
                'created_at' => current_time( 'mysql' ),
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );
    }

    /**
     * @return object[]
     */
    public static function get_logs( array $args = [] ): array {
        global $wpdb;
        $args     = wp_parse_args( $args, [ 'per_page' => 20, 'page' => 1, 'form_id' => 0 ] );
        $offset   = ( max( 1, (int) $args['page'] ) - 1 ) * max( 1, (int) $args['per_page'] );
        $table    = $wpdb->prefix . 'gkform_logs';

        // Select only the columns needed for the list view — NOT body (longtext).
        // Body is fetched separately on demand via get_log_body().
        $cols = 'id, form_id, form_name, sender, subject, status, ip_address, created_at';

        if ( $args['form_id'] > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return (array) $wpdb->get_results( $wpdb->prepare(
                "SELECT {$cols} FROM {$table} WHERE form_id = %d ORDER BY id DESC LIMIT %d OFFSET %d",
                (int) $args['form_id'], (int) $args['per_page'], $offset
            ) );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (array) $wpdb->get_results( $wpdb->prepare(
            "SELECT {$cols} FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d",
            (int) $args['per_page'], $offset
        ) );
    }

    /**
     * Fetch only the body of a single log entry (on-demand, avoids over-fetching in list view).
     */
    public static function get_log_body( int $id ): string {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (string) $wpdb->get_var( $wpdb->prepare(
            "SELECT body FROM {$wpdb->prefix}gkform_logs WHERE id = %d LIMIT 1",
            $id
        ) );
    }

    public static function count_logs( int $form_id = 0 ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'gkform_logs';
        if ( $form_id > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE form_id = %d",
                $form_id
            ) );
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    }

    public static function get_log_stats(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'gkform_logs';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $rows = $wpdb->get_results(
            "SELECT status, COUNT(*) AS cnt FROM {$table} GROUP BY status"
        );
        $stats = [ 'total' => 0, 'sent' => 0, 'failed' => 0 ];
        foreach ( (array) $rows as $row ) {
            $stats[ $row->status ] = (int) $row->cnt;
            $stats['total']       += (int) $row->cnt;
        }
        return $stats;
    }

    public static function delete_log( int $id ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->delete( $wpdb->prefix . 'gkform_logs', [ 'id' => $id ], [ '%d' ] );
    }

    public static function clear_logs( int $form_id = 0 ): void {
        global $wpdb;
        $table = $wpdb->prefix . 'gkform_logs';
        if ( $form_id > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->delete( $table, [ 'form_id' => $form_id ], [ '%d' ] );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->query( "TRUNCATE TABLE {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL
        }
    }
}
