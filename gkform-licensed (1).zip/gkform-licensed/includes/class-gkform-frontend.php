<?php
defined( 'ABSPATH' ) || exit;

class GKForm_Frontend {

    /** Tracks whether the shortcode is rendered on the current page */
    private static bool $assets_needed = false;

    /** Cached client IP for current request */
    private string $client_ip = '';

    public function __construct() {
        // Pre-compute client IP once at construction (used in email footer + log insert)
        $this->client_ip = $this->resolve_client_ip();

        add_shortcode( 'gkform', [ $this, 'render_shortcode' ] );

        // Assets are enqueued in wp_footer only if the shortcode actually rendered
        // Priority 1 ensures scripts appear before closing </body>
        add_action( 'wp_footer', [ $this, 'maybe_enqueue_assets' ], 1 );

        // Form submission — both logged-in and guest users
        add_action( 'wp_ajax_gkform_submit',        [ $this, 'handle_submission' ] );
        add_action( 'wp_ajax_nopriv_gkform_submit', [ $this, 'handle_submission' ] );
    }

    // ── Shortcode renderer ────────────────────────────────────────────────────

    public function render_shortcode( $atts ): string {
        $atts = shortcode_atts( [ 'id' => 0 ], $atts, 'gkform' );
        $id   = absint( $atts['id'] );

        if ( ! $id ) {
            return '';
        }

        $form = GKForm_DB::get_form( $id );
        if ( ! $form ) {
            return '';
        }

        self::$assets_needed = true;

        $fields   = json_decode( $form->form_fields, true ) ?: [];
        $settings = json_decode( $form->settings, true ) ?: [];

        ob_start();
        include GKFORM_DIR . 'templates/form-display.php';
        return (string) ob_get_clean();
    }

    // ── Conditional asset loading ─────────────────────────────────────────────
    // Nothing is loaded unless [gkform] shortcode was rendered on this page.

    public function maybe_enqueue_assets(): void {
        if ( ! self::$assets_needed ) {
            return;
        }

        wp_enqueue_style(
            'gkform-frontend',
            GKFORM_URL . 'assets/css/frontend.css',
            [],
            GKFORM_VERSION
        );

        $site_key = get_option( 'gkform_recaptcha_site_key', '' );
        if ( $site_key ) {
            // Render-blocking is unavoidable for reCAPTCHA; load in footer at least
            wp_enqueue_script(
                'gkform-recaptcha',
                'https://www.google.com/recaptcha/api.js',
                [],
                null,
                true
            );
        }

        wp_enqueue_script(
            'gkform-frontend',
            GKFORM_URL . 'assets/js/frontend.js',
            [ 'jquery' ],
            GKFORM_VERSION,
            true
        );

        wp_localize_script( 'gkform-frontend', 'gkformFrontend', [
            'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'gkform_submit_nonce' ),
            'siteKey'  => $site_key,
            'strings'  => [
                'required'     => __( 'This field is required.', 'gkform' ),
                'invalidEmail' => __( 'Please enter a valid email address.', 'gkform' ),
                'fileTooLarge' => __( 'File "%s" exceeds the maximum allowed size of %s MB.', 'gkform' ),
                'sending'      => __( 'Sending…', 'gkform' ),
                'error'        => __( 'An error occurred. Please try again.', 'gkform' ),
            ],
        ] );
    }

    // ── Form submission handler ────────────────────────────────────────────────

    public function handle_submission(): void {
        // Verify nonce — die immediately if invalid
        if ( ! check_ajax_referer( 'gkform_submit_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed. Please refresh the page.', 'gkform' ) ] );
        }

        $form_id = absint( $_POST['form_id'] ?? 0 );
        if ( ! $form_id ) {
            wp_send_json_error( [ 'message' => __( 'Invalid form.', 'gkform' ) ] );
        }

        $form = GKForm_DB::get_form( $form_id );
        if ( ! $form ) {
            wp_send_json_error( [ 'message' => __( 'Form not found.', 'gkform' ) ] );
        }

        $fields   = json_decode( $form->form_fields, true ) ?: [];
        $settings = json_decode( $form->settings, true ) ?: [];

        // ── reCAPTCHA ─────────────────────────────────────────────────────────
        if ( ! empty( $settings['enable_captcha'] ) ) {
            $this->verify_recaptcha();
        }

        // ── Build email & validate fields ─────────────────────────────────────
        $email_body   = $this->build_email_header( $form->form_name );
        $sender_email = '';

        foreach ( $fields as $field ) {
            $fid   = sanitize_key( $field['id'] );
            $label = esc_html( $field['label'] );
            $type  = $field['type'];
            $req   = ! empty( $field['required'] );

            if ( 'file' === $type ) {
                // Handled below in attachments section
                continue;
            }

            if ( 'checkbox' === $type ) {
                $values    = array_map( 'sanitize_text_field', (array) ( $_POST[ $fid ] ?? [] ) );
                $value_raw = $values;
                $display   = esc_html( implode( ', ', $values ) );
            } else {
                $raw_val   = sanitize_textarea_field( wp_unslash( $_POST[ $fid ] ?? '' ) );
                $value_raw = $raw_val;
                $display   = esc_html( $raw_val );
            }

            // Required validation (server-side backup)
            if ( $req && empty( $value_raw ) ) {
                wp_send_json_error( [
                    'message' => sprintf( __( '%s is required.', 'gkform' ), $field['label'] ),
                    'field'   => $fid,
                ] );
            }

            // Email format
            if ( 'email' === $type && ! empty( $display ) ) {
                if ( ! is_email( $display ) ) {
                    wp_send_json_error( [
                        'message' => __( 'Please enter a valid email address.', 'gkform' ),
                        'field'   => $fid,
                    ] );
                }
                $sender_email = sanitize_email( $display );
            }

            $email_body .= "<p style='margin:0 0 14px;'>"
                . "<strong style='color:#374151;display:block;font-size:12px;text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;'>{$label}</strong>"
                . "<span style='color:#1f2937;'>" . ( $display ?: '<em style="color:#9ca3af;">Not provided</em>' ) . '</span>'
                . "</p>\n";
        }

        // ── File attachments & size validation ────────────────────────────────
        $attachments = [];
        if ( ! empty( $_FILES ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';

            // Build a lookup of field max sizes
            $field_max_sizes = [];
            foreach ( $fields as $f ) {
                if ( 'file' === $f['type'] ) {
                    $field_max_sizes[ sanitize_key( $f['id'] ) ] = absint( $f['max_size'] ?? 0 );
                }
            }

            foreach ( $_FILES as $field_key => $file_data ) {
                $clean_key = sanitize_key( $field_key );
                $max_mb    = $field_max_sizes[ $clean_key ] ?? 0;

                $names     = (array) $file_data['name'];
                $tmp_names = (array) $file_data['tmp_name'];
                $types     = (array) $file_data['type'];
                $errors    = (array) $file_data['error'];
                $sizes     = (array) $file_data['size'];

                foreach ( $names as $idx => $fname ) {
                    if ( empty( $fname ) || ( $errors[ $idx ] ?? UPLOAD_ERR_NO_FILE ) === UPLOAD_ERR_NO_FILE ) {
                        continue;
                    }

                    // File size enforcement (MB)
                    if ( $max_mb > 0 ) {
                        $size_bytes = (int) ( $sizes[ $idx ] ?? 0 );
                        if ( $size_bytes > $max_mb * 1024 * 1024 ) {
                            wp_send_json_error( [
                                'message' => sprintf(
                                    __( 'File "%s" exceeds the maximum allowed size of %d MB.', 'gkform' ),
                                    sanitize_file_name( $fname ),
                                    $max_mb
                                ),
                            ] );
                        }
                    }

                    $single = [
                        'name'     => $fname,
                        'type'     => $types[ $idx ]     ?? '',
                        'tmp_name' => $tmp_names[ $idx ] ?? '',
                        'error'    => $errors[ $idx ]    ?? UPLOAD_ERR_NO_FILE,
                        'size'     => $sizes[ $idx ]     ?? 0,
                    ];

                    $upload = wp_handle_upload( $single, [ 'test_form' => false ] );
                    if ( isset( $upload['file'] ) ) {
                        $attachments[] = $upload['file'];
                        $email_body   .= "<p style='margin:0 0 14px;'>"
                            . "<strong style='color:#374151;display:block;font-size:12px;text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;'>Attachment</strong>"
                            . "<span style='color:#1a56db;'>📎 " . esc_html( $fname ) . '</span>'
                            . "</p>\n";
                    } elseif ( isset( $upload['error'] ) ) {
                        wp_send_json_error( [ 'message' => $upload['error'] ] );
                    }
                }
            }
        }

        $email_body .= $this->build_email_footer();

        // ── Send email ─────────────────────────────────────────────────────────
        $to      = sanitize_email( $settings['to_email'] ?? get_option( 'admin_email' ) );
        $subject = sanitize_text_field( $settings['email_subject'] ?? 'New form submission' );
        if ( ! $to ) {
            $to = sanitize_email( get_option( 'admin_email' ) );
        }

        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        if ( $sender_email ) {
            $headers[] = 'Reply-To: ' . $sender_email;
        }

        $sent = wp_mail( $to, $subject, $email_body, $headers, $attachments );

        // ── Log ───────────────────────────────────────────────────────────────
        $global_logs = get_option( 'gkform_enable_logs', '1' );
        if ( '1' === $global_logs && ! empty( $settings['enable_logs'] ) ) {
            GKForm_DB::insert_log( [
                'form_id'    => $form_id,
                'form_name'  => $form->form_name,
                'sender'     => $sender_email ?: 'unknown',
                'subject'    => $subject,
                'body'       => $email_body,
                'status'     => $sent ? 'sent' : 'failed',
                'ip_address' => $this->client_ip,
            ] );
        }

        if ( $sent ) {
            wp_send_json_success( [
                'message' => wp_kses_post( $settings['success_msg'] ?? 'Thank you! Your message has been sent.' ),
            ] );
        } else {
            wp_send_json_error( [
                'message' => __( 'Message could not be sent. Please try again later.', 'gkform' ),
            ] );
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private function verify_recaptcha(): void {
        $secret   = get_option( 'gkform_recaptcha_secret_key', '' );
        $response = sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ?? '' ) );

        if ( ! $secret ) {
            return; // reCAPTCHA not configured — skip silently
        }

        if ( ! $response ) {
            wp_send_json_error( [ 'message' => __( 'Please complete the CAPTCHA.', 'gkform' ) ] );
        }

        $verify = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', [
            'body'    => [ 'secret' => $secret, 'response' => $response ],
            'timeout' => 8,
        ] );

        if ( is_wp_error( $verify ) ) {
            wp_send_json_error( [ 'message' => __( 'CAPTCHA verification could not be completed.', 'gkform' ) ] );
        }

        $body = json_decode( wp_remote_retrieve_body( $verify ), true );
        if ( empty( $body['success'] ) ) {
            wp_send_json_error( [ 'message' => __( 'CAPTCHA verification failed. Please try again.', 'gkform' ) ] );
        }
    }

    private function build_email_header( string $form_name ): string {
        return "<!DOCTYPE html><html><body style='margin:0;padding:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif;'>"
            . "<div style='max-width:600px;margin:24px auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.08);'>"
            . "<div style='background:linear-gradient(135deg,#1a56db,#3b82f6);padding:24px 28px;'>"
            . "<h2 style='margin:0;color:#fff;font-size:18px;font-weight:700;'>📋 New Form Submission</h2>"
            . "<p style='margin:6px 0 0;color:rgba(255,255,255,.8);font-size:13px;'>" . esc_html( $form_name ) . "</p>"
            . "</div>"
            . "<div style='padding:24px 28px;'>\n";
    }

    private function build_email_footer(): string {
        return "<hr style='border:none;border-top:1px solid #e5e7eb;margin:20px 0;'/>"
            . "<p style='margin:0;color:#9ca3af;font-size:11px;'>"
            . "Submitted via <strong>GK Form</strong> from "
            . esc_html( home_url() )
            . " &bull; IP: " . esc_html( $this->client_ip )
            . " &bull; " . esc_html( current_time( 'mysql' ) )
            . "</p>"
            . "</div></div></body></html>\n";
    }

    private function resolve_client_ip(): string {
        $keys = [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ];
        foreach ( $keys as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    return $ip;
                }
            }
        }
        return 'unknown';
    }
}
