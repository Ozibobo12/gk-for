<?php
/**
 * Themeraft License Validator
 *
 * Drop this file into the root of any theme or plugin sold through Themeraft.
 * Then call:  Themeraft_License::init( 'YOUR-PRODUCT-SLUG' );
 * from your theme's functions.php or plugin's main file.
 *
 * What it does:
 *  1. On first activation  → prompts the user to enter their license key.
 *  2. On key save          → calls the store's /activate endpoint, which
 *                            domain-locks the key to the current site URL.
 *  3. On every admin load  → silently validates the key against the store.
 *  4. If invalid/expired   → shows a dismissible admin notice and removes
 *                            non-admin-critical front-end features.
 *
 * IMPORTANT: Replace THEMERAFT_STORE_URL below with your actual store URL
 * before distributing products.
 *
 * @package Themeraft
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── CONFIGURE THIS ────────────────────────────────────────────────────────────
if ( ! defined( 'THEMERAFT_STORE_URL' ) ) {
    define( 'THEMERAFT_STORE_URL', 'https://vaultt.free.nf/' ); // ← change this
}

// ── VALIDATOR CLASS ───────────────────────────────────────────────────────────
if ( ! class_exists( 'Themeraft_License' ) ) :

class Themeraft_License {

    /** @var string product slug used as option key prefix */
    private static $slug = '';

    /** @var string human-readable product name for notices */
    private static $name = '';

    /** Cache validation result within a request */
    private static $status_cache = null;

    // ── BOOTSTRAP ────────────────────────────────────────────────────────────

    /**
     * Initialise licensing for a product.
     *
     * @param string $product_slug  Short slug, e.g. 'my-awesome-theme'
     * @param string $product_name  Human name, e.g. 'My Awesome Theme'
     */
    public static function init( $product_slug, $product_name = '' ) {
        self::$slug = sanitize_key( $product_slug );
        self::$name = $product_name ?: $product_slug;

        // Settings page (admin only)
        add_action( 'admin_menu',           [ __CLASS__, 'add_settings_page' ] );
        add_action( 'admin_init',           [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_notices',        [ __CLASS__, 'show_notice' ] );

        // Validate periodically (once per hour via transient)
        add_action( 'admin_init',           [ __CLASS__, 'maybe_validate' ] );

        // After theme/plugin activation: clear any cached status
        add_action( 'after_switch_theme',   [ __CLASS__, 'flush_status' ] );
        add_action( 'activated_plugin',     [ __CLASS__, 'flush_status' ] );
    }

    // ── OPTION HELPERS ────────────────────────────────────────────────────────

    private static function opt( $suffix ) {
        return self::$slug . '_license_' . $suffix;
    }

    public static function get_key() {
        return trim( get_option( self::opt( 'key' ), '' ) );
    }

    public static function get_status() {
        return get_option( self::opt( 'status' ), 'inactive' ); // inactive|active|invalid
    }

    public static function flush_status() {
        delete_option( self::opt( 'status' ) );
        delete_transient( self::opt( 'last_check' ) );
        self::$status_cache = null;
    }

    // ── SETTINGS PAGE ─────────────────────────────────────────────────────────

    public static function add_settings_page() {
        add_options_page(
            self::$name . ' — License',
            self::$name . ' License',
            'manage_options',
            self::opt( 'settings' ),
            [ __CLASS__, 'render_settings_page' ]
        );
    }

    public static function register_settings() {
        register_setting(
            self::opt( 'group' ),
            self::opt( 'key' ),
            [ 'sanitize_callback' => [ __CLASS__, 'sanitize_and_activate' ] ]
        );
    }

    /**
     * Sanitize the key field — also fires the activation API call.
     */
    public static function sanitize_and_activate( $raw_key ) {
        $key = strtoupper( sanitize_text_field( trim( $raw_key ) ) );
        if ( ! $key ) {
            self::flush_status();
            return '';
        }

        $result = self::call_store( 'tr_activate_license', $key );

        if ( is_wp_error( $result ) || empty( $result['success'] ) ) {
            $msg = $result instanceof WP_Error
                ? $result->get_error_message()
                : ( $result['data']['message'] ?? 'Activation failed.' );
            add_settings_error( self::opt( 'key' ), 'activation_failed', esc_html( $msg ), 'error' );
            update_option( self::opt( 'status' ), 'invalid' );
            return $key; // Keep the key so user can try again
        }

        update_option( self::opt( 'status' ), 'active' );
        delete_transient( self::opt( 'last_check' ) );
        add_settings_error( self::opt( 'key' ), 'activated', '✓ License activated successfully!', 'updated' );
        return $key;
    }

    public static function render_settings_page() {
        $key    = self::get_key();
        $status = self::get_status();
        $domain = self::get_domain();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( self::$name ); ?> &mdash; License</h1>
            <?php settings_errors( self::opt( 'key' ) ); ?>

            <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:28px;max-width:600px;margin-top:20px;">

                <table class="form-table" style="margin:0;">
                    <tr>
                        <th style="width:130px;padding:8px 0;">Status</th>
                        <td>
                            <?php if ( $status === 'active' ) : ?>
                                <span style="color:#1e9e66;font-weight:700;">&#10003; Active</span>
                                <span style="color:#888;font-size:.85em;margin-left:10px;">Locked to: <?php echo esc_html( $domain ); ?></span>
                            <?php elseif ( $status === 'invalid' ) : ?>
                                <span style="color:#c00;font-weight:700;">&#10007; Invalid</span>
                            <?php else : ?>
                                <span style="color:#888;font-weight:600;">Inactive &mdash; enter your key below</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>

                <hr style="margin:20px 0;">

                <form method="post" action="options.php">
                    <?php settings_fields( self::opt( 'group' ) ); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="<?php echo esc_attr( self::opt('key') ); ?>">License Key</label></th>
                            <td>
                                <input type="text"
                                       id="<?php echo esc_attr( self::opt('key') ); ?>"
                                       name="<?php echo esc_attr( self::opt('key') ); ?>"
                                       value="<?php echo esc_attr( $key ); ?>"
                                       placeholder="TRAFT-XXXXXXXX-XXXXXXXX-XXXXXXXX"
                                       class="regular-text"
                                       style="font-family:monospace;letter-spacing:.06em;">
                                <p class="description">
                                    Your license key was emailed after purchase and is also visible
                                    in your <a href="<?php echo esc_url( THEMERAFT_STORE_URL . '/dashboard/' ); ?>" target="_blank">Themeraft Dashboard</a>.
                                </p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button( $status === 'active' ? 'Re-activate License' : 'Activate License' ); ?>
                </form>

                <?php if ( $status === 'active' ) : ?>
                <hr style="margin:20px 0;">
                <p style="color:#888;font-size:.85em;">
                    To use this license on a different domain, first deactivate it from your
                    <a href="<?php echo esc_url( THEMERAFT_STORE_URL . '/dashboard/' ); ?>" target="_blank">Themeraft Dashboard</a>,
                    then enter the key here again.
                </p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    // ── PERIODIC VALIDATION ───────────────────────────────────────────────────

    public static function maybe_validate() {
        $key = self::get_key();
        if ( ! $key ) return;

        // Check at most once per hour
        if ( get_transient( self::opt( 'last_check' ) ) ) return;
        set_transient( self::opt( 'last_check' ), 1, HOUR_IN_SECONDS );

        $result = self::call_store( 'tr_validate_license', $key );
        if ( is_wp_error( $result ) ) return; // Network error — keep previous status

        $status = ( ! empty( $result['success'] ) ) ? 'active' : 'invalid';
        update_option( self::opt( 'status' ), $status );
    }

    // ── ADMIN NOTICE ──────────────────────────────────────────────────────────

    public static function show_notice() {
        $key    = self::get_key();
        $status = self::get_status();

        if ( $status === 'active' ) return; // All good — no notice

        $settings_url = admin_url( 'options-general.php?page=' . self::opt( 'settings' ) );
        $product      = esc_html( self::$name );

        if ( ! $key ) {
            $msg = sprintf(
                '<strong>%s</strong> — License key required. <a href="%s">Enter your license key →</a>',
                $product, esc_url( $settings_url )
            );
            $type = 'notice-warning';
        } else {
            $msg = sprintf(
                '<strong>%s</strong> — License key is invalid or domain mismatch. <a href="%s">Check license settings →</a>',
                $product, esc_url( $settings_url )
            );
            $type = 'notice-error';
        }
        echo '<div class="notice ' . esc_attr( $type ) . ' is-dismissible"><p>' . wp_kses_post( $msg ) . '</p></div>';
    }

    // ── HTTP HELPER ───────────────────────────────────────────────────────────

    /**
     * POST to the store's AJAX endpoint.
     *
     * @return array|WP_Error  Decoded JSON array or WP_Error on network failure.
     */
    private static function call_store( $action, $key ) {
        $domain = self::get_domain();
        $url    = trailingslashit( THEMERAFT_STORE_URL ) . 'wp-admin/admin-ajax.php';

        $response = wp_remote_post( $url, [
            'timeout' => 15,
            'body'    => [
                'action'      => $action,
                'license_key' => $key,
                'domain'      => $domain,
            ],
        ] );

        if ( is_wp_error( $response ) ) return $response;

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return is_array( $body ) ? $body : new WP_Error( 'parse_error', 'Invalid response from license server.' );
    }

    /**
     * Get the bare hostname of the current site (no www, no protocol, no path).
     */
    private static function get_domain() {
        $host = strtolower( parse_url( home_url(), PHP_URL_HOST ) ?: '' );
        $host = preg_replace( '/^www\./', '', $host );
        $host = preg_replace( '/:\d+$/', '', $host );
        return $host;
    }

    // ── PUBLIC STATUS CHECK (for conditional features) ────────────────────────

    /**
     * Returns true only when the license is confirmed active on this domain.
     * Themes/plugins can use this to gate premium features:
     *   if ( ! Themeraft_License::is_active() ) { return; }
     */
    public static function is_active() {
        if ( self::$status_cache === null ) {
            self::$status_cache = ( self::get_status() === 'active' );
        }
        return self::$status_cache;
    }
}

endif; // class_exists
