<?php
/**
 * Plugin Name:       GK Form
 * Plugin URI:        https://github.com/gkform
 * Description:       Lightweight, speed-optimised contact form builder with drag-and-drop fields, email logs, CAPTCHA, and shortcode rendering. Zero frontend impact unless the shortcode is used.
 * Version:           1.3.0
 * Author:            GK Form
 * Text Domain:       gkform
 * License:           GPL-2.0+
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

defined( 'ABSPATH' ) || exit;

// ─── Constants ────────────────────────────────────────────────────────────────
define( 'GKFORM_VERSION',    '1.3.0' );
define( 'GKFORM_FILE',       __FILE__ );
define( 'GKFORM_DIR',        plugin_dir_path( __FILE__ ) );
define( 'GKFORM_URL',        plugin_dir_url( __FILE__ ) );
define( 'GKFORM_DB_VERSION', '1.1' );

// ─── Autoloader ───────────────────────────────────────────────────────────────
spl_autoload_register( static function ( string $class ): void {
    if ( strpos( $class, 'GKForm_' ) !== 0 ) {
        return;
    }
    $slug = strtolower( str_replace( [ 'GKForm_', '_' ], [ '', '-' ], $class ) );
    $file = GKFORM_DIR . 'includes/class-gkform-' . $slug . '.php';
    if ( file_exists( $file ) ) {
        require_once $file;
    }
} );

// ─── Activation / Deactivation ────────────────────────────────────────────────
register_activation_hook( __FILE__, static function (): void {
    require_once GKFORM_DIR . 'includes/class-gkform-db.php';
    GKForm_DB::install();
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, static function (): void {
    flush_rewrite_rules();
} );

// ─── Licensing ────────────────────────────────────────────────────────────────
require_once GKFORM_DIR . 'includes/license-validator.php';
Themeraft_License::init( 'gkform', 'GK Form' );

// ─── License gate: redirect all GK Form pages if license is not active ────────
add_action( 'admin_init', static function (): void {
    if ( wp_doing_ajax() ) {
        return;
    }

    $page         = sanitize_key( $_GET['page'] ?? '' );
    $gkform_pages = [ 'gkform', 'gkform-builder', 'gkform-logs', 'gkform-settings' ];

    if ( ! in_array( $page, $gkform_pages, true ) ) {
        return;
    }

    if ( Themeraft_License::is_active() ) {
        return;
    }

    // License not active — send user to the license entry page
    wp_safe_redirect( admin_url( 'options-general.php?page=gkform_license_settings' ) );
    exit;
} );

// ─── Bootstrap ────────────────────────────────────────────────────────────────
add_action( 'init', static function (): void {
    if ( is_admin() && ! wp_doing_ajax() ) {
        GKForm_DB::maybe_upgrade();
    }

    if ( is_admin() ) {
        $ajax_action      = sanitize_key( $_REQUEST['action'] ?? '' );
        $is_frontend_ajax = wp_doing_ajax() && 'gkform_submit' === $ajax_action;

        // Only boot the full admin UI when the license is confirmed active
        if ( ! $is_frontend_ajax && Themeraft_License::is_active() ) {
            new GKForm_Admin();
        }
    }

    // Shortcode always works on the front end regardless of license
    new GKForm_Frontend();
}, 10 );
